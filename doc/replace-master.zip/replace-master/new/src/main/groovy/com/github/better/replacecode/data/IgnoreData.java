package com.github.better.replacecode.data;

import java.util.ArrayList;
import java.util.List;

/**
 * 忽略数据
 */
public class IgnoreData {

    private static List<String> list;
    private static List<String> list1;
    private static List<String> list2;
    private static List<String> list3;
    private static List<String> list4;

    /**
     * 命名  忽略的 字符
     *
     * @return
     */
    public static List<String> getList() {
        if (null == list) {
            list = new ArrayList<>();
            list.add("String");
            list.add("Int");
            list.add("boolean");
            list.add("Boolean");
            list.add("float");
            list.add("protected");
            list.add("private");
            list.add("class");
            list.add("extends");
            list.add("implements");
            list.add("static");
            list.add("void");
            list.add("SeekBar");
            list.add("public");
            list.add("Context");
            list.add("LinearLayout");
            list.add("TextView");
            list.add("RelativeLayout");
            list.add("EditText");
            list.add("View");
            list.add("ScrollView");
            list.add("ImageView");
            list.add("SVGAImageView");
            list.add("SimpleMarqueeView");
            list.add("SwipeRefreshLayout");
            list.add("NestedScrollView");
            list.add("RecyclerView");
            list.add("FrameLayout");
            list.add("final");
        }
        return list;
    }

    public static boolean isEligibility(String sr) {
        for (String s : getList()) {
            if (s.equals(sr)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 类中 常量 忽略的 字符
     *
     * @return
     */
    public static List<String> getCFList() {
        if (null == list1) {
            list1 = new ArrayList<>();
            list1.add("LinearLayout");
            list1.add("SeekBar");
            list1.add("ConstraintLayout");
            list1.add("LinearLayout");
            list1.add("TextView");
            list1.add("RelativeLayout");
            list1.add("EditText");
            list1.add("View");
            list1.add("ScrollView");
            list1.add("ImageView");
            list1.add("SVGAImageView");
            list1.add("SimpleMarqueeView");
            list1.add("SwipeRefreshLayout");
            list1.add("NestedScrollView");
            list1.add("RecyclerView");
            list1.add("FrameLayout");
            list1.add("RadioGroup");
            list1.add("RadioButton");
            list1.add("Button");
            list1.add("ImageButton");
            list1.add("ProgressBar");
            list1.add("Button");
            list1.add("CheckBox");


        }
        return list1;
    }

    /**
     * 常量 修改忽略的 数据
     *
     * @param sr
     * @return
     */
    public static boolean isElbility(String sr) {
        for (String s : getCFList()) {
            if (sr.contains(s)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 忽略的 字符
     *
     * @return
     */
    public static List<String> getListIgnore() {
        if (null == list2) {
            list2 = new ArrayList<>();
            list2.add("View");
            list2.add("onClick");
            list2.add("Context");
            list2.add("getName");
            list2.add("this");
            list2.add("setData");
            list2.add("getData");
            list2.add("newInstance");
            list2.add("client");
            list2.add("run");
            list2.add("handleMessage");
            list2.add("onTouchEvent");
            list2.add("savedInstanceState");
            list2.add("onCreate");
            list2.add("bindToLifecycle");
            list2.add("set");
        }
        return list2;
    }

    /**
     * 常量 修改忽略的 数据
     *
     * @param sr
     * @return
     */
    public static boolean isIgnoreElbility(String sr) {
        for (String s : getListIgnore()) {
            if (sr.equals(s)) {
                return true;
            }
        }
        return false;
    }


    /**
     * 忽略的 继承  实现的类名
     *
     * @return
     */
    public static List<String> getListIgnore1() {
        if (null == list3) {
            list3 = new ArrayList<>();
            list3.add("Serializable");
            list3.add("BaseNode");
            list3.add("BaseExpandNode");
            list3.add("Parcelable");
        }
        return list3;
    }

    /**
     * 常量 修改忽略的 数据
     *
     * @param sr
     * @return
     */
    public static boolean isIgnoreElbility1(String sr) {
        for (String s : getListIgnore1()) {
            if (sr.contains(s)) {
                return true;
            }
        }
        return false;
    }
}

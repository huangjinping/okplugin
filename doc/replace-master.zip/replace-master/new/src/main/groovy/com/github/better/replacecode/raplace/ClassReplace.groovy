package com.github.better.replacecode.raplace

import com.github.better.Constant
import com.github.better.replacecode.CodeNewConfiguration
import com.github.better.replacecode.NewStr
import com.github.better.replacecode.data.IgnoreData
import com.github.better.replacecode.data.ReplaceData
import com.github.better.tools.GetNameAutomatically
import com.github.better.tools.JavaClassFile
import com.github.better.tools.StringUtils
import java.lang.reflect.Modifier
import java.util.regex.Matcher

/**
 * layout 布局资源
 */
public class ClassReplace {
    /**
     *  替换数据
     */
    List<ReplaceData> replaceDataList = new ArrayList<ReplaceData>();

    /**
     * 获取 随机类
     */
    GetNameAutomatically getNameAutomatically
    Map<String, String> replaceMap;

    ClassReplace() {
        getNameAutomatically = GetNameAutomatically.getInstance(CodeNewConfiguration.getInstance())
    }


    /**
     * 入口 类
     * @throws IOException
     */
    public void replaceThis() throws IOException {
//        println " 要处理的 数据 -----" + CodeNewConfiguration.ReviseFilePath.toString()
        CodeNewConfiguration.CalssFilePath.each {
//            println " 方法要处理的 数据 -----" + it
            File classFile = new File(it)
            String name = classFile.getName().replace("class", "")
//            println " classFile 的名字 -----" + name
            if (!classFile.isDirectory()) {
                CodeNewConfiguration.ReviseFilePath.each { String str ->
                    File javaFile = new File(str)
                    String javaname = javaFile.getName().replace("java", "")
//                    println " javaFile 的名字 -----" + javaname
                    if (name == javaname) {
                        handleSrcFile(classFile, javaFile)
                        return
                    }
                }
            }
        }

        //去除 private 修饰的变量
        Map<String, String> replaceMap = new HashMap<String, String>()
        for (i in 0..<replaceDataList.size()) {
            ReplaceData replaceData = replaceDataList.get(i)
            if (replaceData.isReplace()) {
                replaceMap.put(replaceData.getOldName(), replaceData.getNewName())
            }
        }
        println "要替换的 数据 -----" + replaceMap.toString()
        //文件名 更改
        new FileNameReplace().replaceCode(replaceMap)
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     * @param line
     * @return
     */
    private List<Map.Entry<String, String>> getString(String line) {
        List<Map.Entry<String, String>> map = new ArrayList<>()
        for (Map.Entry<String, String> en : replaceMap.entrySet()) {
            if (line.contains(en.key)) {
                println "replaceMap 中 对应的 数据 -----" + en
                map.add(en)

            }
        }
        //根据 key 的长度 排序  长 --> 短
        Collections.sort(map, new Comparator<Map.Entry<String, String>>() {
            @Override
            int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
                if (o1.key.length() > o2.key.length()) {
                    return -1;
                } else if (o1.key.length() < o2.key.length()) {
                    return 1;
                }
                return 0
            }
        })
        return map
    }

    /**
     * 继承 实现的一些类  忽略处理
     * @param classFile
     * @param javaFile
     */
    private boolean getIgnoreClass(JavaClassFile javaClassFile) {
        List<String> mSupporList = new ArrayList<String>();
        mSupporList.addAll(javaClassFile.getInterfaceNames().toList())
        mSupporList.add(javaClassFile.getSuperClassName())
        if (mSupporList.size() > 0) {
            for (i in 0..<mSupporList.size()) {
                if (IgnoreData.isIgnoreElbility1(mSupporList.get(i))) {
//                    println "有 继承 实现类 -----" + mSupporList.get(i)
                    return true
                }
            }
        }
        return false
    }


    private void handleSrcFile(File classFile, File javaFile) {
        JavaClassFile javaClassFile = new JavaClassFile(classFile)
//        println " 类 数据 -----" + javaClassFile.toString()

        // 继承 实现的一些类  忽略处理
        if (getIgnoreClass(javaClassFile)) {
//            println " 继承 实现的一些类  忽略处理-----"
            return
        }
//        println " 继承 实现的一些类 没有 忽略处理-----"
        // 全局变量数据
        List<JavaClassFile.Member> memberList = getmembersList(javaClassFile)
        //private  Static  方法 数据
        List<JavaClassFile.Member> methodsList = getMethodsList(javaClassFile)

        //init    方法 数据
//        JavaClassFile.Member methodsList2 = getMethodsList2(javaClassFile)

        //public   方法 数据
        List<JavaClassFile.Member> methodsList1 = getMethodsList1(javaClassFile)

        //接口 类名 数据
        javaClassFile.getAttributes().each {
//            println " Attributes 名-----" + it.toString()
            JavaClassFile.Attribute.InnerClass[] innerClasses = it.getInnerClasses()
            if (null != innerClasses) {
//                println " InnerClass 名-----" + innerClasses.toString()
                innerClasses.each { JavaClassFile.Attribute.InnerClass innerClass ->
//                    println javaClassFile.getThisClassName() + " 接口类 名--" + innerClass.outerClassName() + "--- 修饰" + innerClass.getInnerAccessFlags()
                    if (!StringUtils.isEs(innerClass.outerClassName()) && !StringUtils.isEs(javaClassFile.getThisClassName()) && innerClass.outerClassName() == javaClassFile.getThisClassName() && innerClass.getInnerAccessFlags().contains("interface")) {
                        String innerClassName = innerClass.innerClassName()
                        String innerName = innerClass.innerName()
                        println " 接口类 名-----" + innerName
                        innerClassName = innerClassName.replace("\$" + innerName, "")
//                        println " 接口类 -----" + innerClassName

                        CodeNewConfiguration.CalssFilePath.each { String inner ->
//                            println " 接口类 1111111-----" + inner
                            if (inner.replaceAll("\\\\", "\\/").contains(innerClassName)) {
                                println " 接口类 22222222-----" + inner
                                JavaClassFile javaClassFile1 = new JavaClassFile(new File(inner))
                                methodsList1.addAll(javaClassFile1.getMethods().toList())
                                String newInterfaceName = getNewString4(innerName)
                                if (StringUtils.isEs(newInterfaceName)) {
                                    replaceDataList.add(new ReplaceData(innerName, getNewString9(), true))
                                }
                            }
                        }
                    }
                }
            }
        }
//        println " 接口  方法 数据 -----" + methodsList1.toString()
//
//        List<JavaClassFile.Attribute.LocalVariable[]> localVariableTableList = javaClassFile.getLocalVariableTableList()
//        println " 局部变量 数据 -----" + localVariableTableList.toString()


        StringBuffer sb = new StringBuffer()
        javaFile.eachLine("UTF-8") { line ->
            println " 类数据 -----" + line.toString()
            if (null != line && !StringUtils.isEs(line.toString())) {
                line = modificationStr(line)
                //全局 变量 替换
                line = replaceFieldName(memberList, line)

                //private  Static  方法名 入参  替换
                line = replaceMethodName1(methodsList, line)

                //public   方法名 入参  替换
                line = replaceMethodName2(methodsList1, line)


                // R. 字符 替换 回 原来的字符
                if (map.size() > 0) {
                    for (Map.Entry<String, String> en : map.entrySet()) {
                        line = StringUtils.replaceCharacter(line, en.key, en.value);
                    }
                    map.clear()
                }
            }
            sb.append(line + "\r\n")
        }

        javaFile.write(sb.toString(), "UTF-8")// 写回文件
    }

    int sum1 = -1
    int sum2 = -1
    List<String> mParameterNames = new ArrayList<String>();

    /**
     * init  数据 处理
     * @param javaClassFile
     * @return
     */
//    private JavaClassFile.Member getMethodsList2(JavaClassFile javaClassFile) {
//        List<JavaClassFile.Member> methodsList = javaClassFile.getMethods().toList()
//        if (null == methodsList || methodsList.size() == 0) {
//            return null
//        }
////        println " 方法名 数据 -----" + methodsList.toString()
//
//        List<Integer> mIgnoreList = new ArrayList<Integer>();
//
//        for (int i = 0; i < methodsList.size(); i++) {
//            JavaClassFile.Member method = methodsList.get(i)
//            if (method.isConstructor() && method.isMethod()) {
////                println " 字段 数据  坐标 -----" + i
//                mIgnoreList.add(i)
//            }
//        }
//        if (null == mIgnoreList || mIgnoreList.size() == 0) {
//            return null
//        } else {
//            JavaClassFile.Member initMethod = new JavaClassFile.Member();
//            initMethod.name = javaClassFile.getThisClassName()
//            mIgnoreList.each {
//                initMethod.setMethodParametersName(methodsList.get(it.intValue()).getMethodParametersName())
//            }
//            return initMethod
//        }
//    }
    /**
     *  public   数据 处理
     * @param javaClassFile
     * @return
     */
    private List<JavaClassFile.Member> getMethodsList1(JavaClassFile javaClassFile) {
        List<JavaClassFile.Member> methodsList = javaClassFile.getMethods().toList()
        if (null == methodsList || methodsList.size() == 0) {
            return new ArrayList();
        }
//        println " 方法名 数据 -----" + methodsList.toString()

        List<Integer> mIgnoreList = new ArrayList<Integer>();

        for (int i = 0; i < methodsList.size(); i++) {
            JavaClassFile.Member method = methodsList.get(i)
            if (method.isPublic() && !method.isConstructor() && method.isMethod()) {
//                println " 字段 数据  坐标 -----" + i
                mIgnoreList.add(i)
            }
        }

        List<JavaClassFile.Member> methodsList1 = new ArrayList()
        mIgnoreList.each {
            methodsList1.add(methodsList.get(it.intValue()))
        }
        return methodsList1
    }

    int mOverride = -1
//    /**
//     *  public  方法名 入参  替换
//     */
//    private String replaceMethodName3(List<JavaClassFile.Member> methodsList1, String line) {
//        if (null == methodsList1 || methodsList1.size() == 0) {
//            return line
//        }
//
//        if (line.contains(");")) {
//            line.replace(line.indexOf("("),)
//        }
//
//
//        if (line.contains("@Override")) {
//            mOverride = 0
//        } else if (-1 != mOverride) {
//            mOverride = mOverride + 1
//        }
//        // 方法名 入参 替换 逻辑
//        methodsList1.each {
////            println "public 方法 数据 -----" + it.toString()
//            //方法名 修改
//            if (line.contains(it.name + "(") && !StringUtils.frontCode(line, it.name) && line.contains(Modifier.toString(it.accessFlags)) && !IgnoreData.isIgnoreElbility(it.name)) {
//                if (1 != mOverride) {
//                    mParameterNames.clear()
//                    mParameterNames.addAll(it.getMethodParametersName())
////                    println "public 方法 入参数据 -----" + mParameterNames.toString()
//                    sum1 = 0
//                    sum2 = 0
//                    String newName = getNewString4(it.name + "(")
////                    println " 方法新 名 数据1 -----" + newName
//                    if (StringUtils.isEs(newName)) {
//                        newName = getNewString8() + "("
//                        replaceDataList.add(new ReplaceData(it.name + "(", newName, true))
//                    }
////                    println " replaceDataList 数据 -----" + replaceDataList.toString()
//                    line = line.replace(it.name + "(", newName)
//                }
//            }
//        }
//        //方法 变量  修改
//        if (null != mParameterNames && mParameterNames.size() > 0) {
//            mParameterNames.each { String str ->
////                println " 方法旧 名参数 数据1 -----" + str
//                if (null != str && str.length() != 1) {
//
//                    if (line.contains(str) && !StringUtils.frontCode(line, str) && !IgnoreData.isIgnoreElbility(str)) {
//                        String newName = getNewString3(str)
////                        println " 方法新 名参数 数据1 -----" + newName
//                        if (StringUtils.isEs(newName)) {
//                            newName = getNewString2()
//                            localVariableName.put(str, newName)
//                        }
////                        println " localVariableName 数据 -----" + localVariableName.toString()
//                        line = line.replace(str, newName)
//                    }
//
//                }
//            }
//            if (sum1 != -1) {
//                if (line.contains("{")) {
//                    sum1 = sum1 + 1
//                }
//                if (line.contains("}")) {
//                    sum2 = sum2 + 1
//                }
//                if (sum1 != 0 && sum2 != 0 && sum1 == sum2) {
////                    println " localVariableName 数据 删除 -----" + sum1 + "---" + sum2
//                    sum1 = -1
//                    sum2 = -1
//                    mParameterNames.clear()
//                    localVariableName.clear()
//                }
//            }
//        }
//        return line
//    }

    /**
     * abstract  修饰的 判断
     *
     * 修饰符  的判断
     */
    private boolean getVloSo(String line, JavaClassFile.Member it) {
        String mModifier = Modifier.toString(it.accessFlags);
        if (mModifier.contains("abstract")) {
            return true;
        }
        return line.contains(mModifier)
    }

    /**
     *  public  方法名 入参  替换
     */
    private String replaceMethodName2(List<JavaClassFile.Member> methodsList1, String line) {
        if (null == methodsList1 || methodsList1.size() == 0) {
            return line
        }
        if (line.contains("@Override") || line.contains("@POST") || line.contains("@JavascriptInterface")) {
            mOverride = 0
        } else if (-1 != mOverride) {
            mOverride = mOverride + 1
        }
        /***
         * sum1 sum2 等于 -1 表示 不在方法中
         * 不在方法中 再查看是否有对应的方法名
         */
        if ((-1 == sum1 && -1 == sum2) || (0 == sum1 && 0 == sum2)) {
            // 方法名 入参 替换 逻辑
            methodsList1.each {
//            println "public 方法 数据 -----" + it.toString()
                //方法名 修改
                if (line.contains(it.name + "(") && !StringUtils.frontCode(line, it.name) && getVloSo(line, it) && !IgnoreData.isIgnoreElbility(it.name)) {
                    if (1 != mOverride) {
                        mParameterNames.clear()
                        mParameterNames.addAll(it.getMethodParametersName())
                        println "public 方法 入参数据 -----" + mParameterNames.toString()
                        sum1 = 0
                        sum2 = 0
                        String newName = getNewString4(it.name + "(")
                        println " 方法新 名 数据1 -----" + newName
                        if (StringUtils.isEs(newName)) {
                            newName = getNewString8() + "("
                            replaceDataList.add(new ReplaceData(it.name + "(", newName, true))
                        }
                        println " replaceDataList 数据 -----" + replaceDataList.toString()
                        line = line.replace(it.name + "(", newName)
                    }
                }
            }
        }
        //方法 变量  修改
        if (null != mParameterNames && mParameterNames.size() > 0) {
            mParameterNames.each { String str ->
                println " 方法旧 名参数 数据1 -----" + str
                if (null != str && str.length() != 1) {

                    if (line.contains(str) && !StringUtils.frontCode(line, str) && !IgnoreData.isIgnoreElbility(str)) {
                        String newName = getNewString3(str)
                        println " 方法新 名参数 数据1 -----" + newName
                        if (StringUtils.isEs(newName)) {
                            newName = getNewString2()
                            localVariableName.put(str, newName)
                        }
                        println " localVariableName 数据 -----" + localVariableName.toString()
                        line = line.replace(str, newName)
                    }

                }
            }
//          println " 类 数据  -----" + line
            if (sum1 != -1) {
                if (line.contains("{")) {
                    sum1 = sum1 + 1
                }
                if (line.contains("}")) {
                    sum2 = sum2 + 1
                }
                println "大括号 数据 -----" + sum1 + "---" + sum2
                if (sum1 != 0 && sum2 != 0 && sum1 == sum2) {
                    println " localVariableName 数据 删除 -----" + sum1 + "---" + sum2
                    sum1 = -1
                    sum2 = -1
                    mParameterNames.clear()
                    localVariableName.clear()
                }
            }
        }
        return line
    }

    /**
     *  private Static   数据 处理
     * @param javaClassFile
     * @return
     */
    private List<JavaClassFile.Member> getMethodsList(JavaClassFile javaClassFile) {
        List<JavaClassFile.Member> methodsList = javaClassFile.getMethods().toList()
        if (null == methodsList || methodsList.size() == 0) {
            return null
        }
//        println " 方法名 数据 -----" + methodsList.toString()

        List<Integer> mIgnoreList = new ArrayList<Integer>();

        for (int i = 0; i < methodsList.size(); i++) {
            JavaClassFile.Member method = methodsList.get(i)
            if (method.isPrivateStatic() && !method.isConstructor() && method.isMethod()) {
//                println " 字段 数据  坐标 -----" + i
                mIgnoreList.add(i)
            }
        }

        List<JavaClassFile.Member> methodsList1 = new ArrayList()
        mIgnoreList.each {
            methodsList1.add(methodsList.get(it.intValue()))
        }
        return methodsList1
    }

    /**
     *  private  Static  方法名 入参  替换
     */
    private String replaceMethodName1(List<JavaClassFile.Member> methodsList1, String line) {
        if (null == methodsList1 || methodsList1.size() == 0) {
            return line
        }
        // 方法名 入参 替换 逻辑
        methodsList1.each {

            //方法名 修改
            if (line.contains(it.name + "(") && !StringUtils.frontCode(line, it.name) && !IgnoreData.isIgnoreElbility(it.name)) {
//                println "private  Static 方法 数据 -----" + it.toString()
                if (line.contains(Modifier.toString(it.accessFlags))) {
                    mParameterNames.clear()
                    mParameterNames.addAll(it.getMethodParametersName())
                    sum1 = 0
                    sum2 = 0
//                    println "private  Static 方法 入参数据 -----" + mParameterNames.toString()
                }
                String newName = getNewString4(it.name + "(")
//                println " 方法新 名 数据1 -----" + newName
                if (StringUtils.isEs(newName)) {
                    newName = getNewString8() + "("
                    if (it.isStatic()) {
                        replaceDataList.add(new ReplaceData(it.name + "(", newName, true))
                    } else {
                        replaceDataList.add(new ReplaceData(it.name + "(", newName, false))
                    }
                }
//                println " replaceDataList 数据 -----" + replaceDataList.toString()
                line = line.replace(it.name + "(", newName)
            }
        }
        //方法 变量  修改
        if (null != mParameterNames && mParameterNames.size() > 0) {
            mParameterNames.each { String str ->
//                println " 方法旧 名参数 数据1 -----" + str
                if (null != str && str.length() != 1) {
                    if (line.contains(str) && !StringUtils.frontCode(line, str) && !IgnoreData.isIgnoreElbility(str)) {
                        String newName = getNewString3(str)
//                        println " 方法新 名参数 数据1 -----" + newName
                        if (StringUtils.isEs(newName)) {
                            newName = getNewString2()
                            localVariableName.put(str, newName)
                        }
//                        println " localVariableName 数据 -----" + localVariableName.toString()
                        line = line.replace(str, newName)
                    }
                }
            }
            if (sum1 != -1) {
                if (line.contains("{")) {
                    sum1 = sum1 + 1
                }
                if (line.contains("}")) {
                    sum2 = sum2 + 1
                }
                if (sum1 != 0 && sum2 != 0 && sum1 == sum2) {
//                    println " localVariableName 数据 删除 -----" + sum1 + "---" + sum2
                    sum1 = -1
                    sum2 = -1
                    mParameterNames.clear()
                    localVariableName.clear()
                }
            }
        }
        return line
    }


    /**
     * 全局变量 数据 处理
     * @param javaClassFile
     * @return
     */
    private List<JavaClassFile.Member> getmembersList(JavaClassFile javaClassFile) {
        List<JavaClassFile.Member> membersList = javaClassFile.getFields().toList()
        if (null == membersList || membersList.size() == 0) {
            return null
        }

        List<Integer> mIgnoreList = new ArrayList<Integer>();

        for (int i = 0; i < membersList.size(); i++) {
            if (!IgnoreData.isElbility(membersList.get(i).getDescriptorName())) {
//                println " 字段 数据  坐标 -----" + i
                mIgnoreList.add(i)
            }
        }

        List<JavaClassFile.Member> membersList1 = new ArrayList()
        mIgnoreList.each {
            membersList1.add(membersList.get(it.intValue()))
        }
        return membersList1
    }


    /**
     *  全局 字段名 替换
     */
    private String replaceFieldName(List<JavaClassFile.Member> membersList1, String line) {
        if (null == membersList1 || membersList1.size() == 0) {
            return line
        }
        // 全局变量 替换 逻辑
        membersList1.each {
//            println " 字段 数据 -----" + it.toString()
            if (line.contains(it.name) && !StringUtils.frontCode(line, it.name)) {
                String newName = getNewString4(it.name)
//                println " 新字段 数据1 -----" + newName

                if (StringUtils.isEs(newName)) {
                    if (it.isFinal() || it.isStatic()) {
                        newName = getNewString6()
                    } else {
                        newName = getNewString5()
                    }

//                    println " 新字段 数据 2-----" + newName + "----变量 修饰符---" + it.getAccessFlagsString()
                    if ("private" != it.getAccessFlagsString()) {
                        replaceDataList.add(new ReplaceData(it.name, newName, true))
                    } else {
                        replaceDataList.add(new ReplaceData(it.name, newName, false))
                    }
                }
//                println " replaceDataList 数据 -----" + replaceDataList.toString()
                line = line.replace(it.name, newName)
                return
            }
        }
        return line
    }


    /**
     * 生成 全部大写 的字符
     * @return
     */
    private String getNewString6() {
        String newName = NewStr.getInstance().getAllCapsString()
        boolean flag = false

        replaceDataList.each {
            if (newName.trim() == it.getNewName().trim()) {
                flag = true
                return
            }
        }

        if (flag) {
            return getNewString6();
        }
        return newName
    }
    /**
     * 生成 首字母 小写 的字符
     * @return
     */
    private String getNewString8() {
        String newName = NewStr.getInstance().getLowerCaseString()
        boolean flag = false
        replaceDataList.each {
            if (newName.trim() + "(" == it.getNewName().trim()) {
                flag = true
                return
            }
        }

        if (flag) {
            return getNewString5();
        }
        return newName
    }


    /**
     * 生成 首字母 大写 的字符
     * @return
     */
    private String getNewString9() {
        String newName = NewStr.getInstance().getInitialsString()
        boolean flag = false
        replaceDataList.each {
            if (newName.trim() == it.getNewName().trim()) {
                flag = true
                return
            }
        }

        if (flag) {
            return getNewString9();
        }
        return newName
    }
    /**
     * 生成 首字母 小写 的字符
     * @return
     */
    private String getNewString5() {
        String newName = NewStr.getInstance().getLowerCaseString()
        boolean flag = false
        replaceDataList.each {
            if (newName.trim() == it.getNewName().trim()) {
                flag = true
                return
            }
        }

        if (flag) {
            return getNewString5();
        }
        return newName
    }

    /**
     * 对比 替换数据 中 旧字符串 是否已经有了
     * @param oldName
     * @return
     */
    private String getNewString4(String oldName) {
        String newName = null
        replaceDataList.each {
            if (oldName.trim() == it.getOldName().trim()) {
                newName = it.getNewName()
                return
            }
        }
        return newName
    }

    /**
     * 方法 内 局部变量
     */
    Map<String, String> localVariableName = new HashMap<>();

    private String getNewString3(String oldName) {
        for (Map.Entry<String, String> en : localVariableName.entrySet()) {
//            System.out.println("replaceMap 中 对应的   数据 -----" + en + "----" + en.getKey());
            if (oldName.trim() == en.getKey().trim()) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en.getValue();
            }
        }
        return null
    }

    JavaClassFile.Member currentMethod

    private String findAFit(String line, JavaClassFile.Member[] methods) {
        methods.each {
            if (line.contains(it.getAccessFlagsString()) && line.contains(it.name + "(") && !StringUtils.frontCode(line, it.name)) {
                String newName = getNewString4(it.name + "(")
                if (StringUtils.isEs(newName)) {
                    newName = getNewString5()
                    if (!"private".equals(it.getAccessFlagsString())) {
                        replaceDataList.add(new ReplaceData(it.name + "(", newName + "(", true))
                    } else {
                        replaceDataList.add(new ReplaceData(it.name + "(", newName + "(", false))
                    }
                }
                line = line.replace(it.name + "(", newName + "(")
                if (!it.getDescriptorName().contains("()")) {
                    currentMethod = it
                } else {
                    currentMethod = null
                }
            }
        }
        return line
    }

    private String getNewString2() {
        String newName = NewStr.getInstance().getLowerCaseString()
        boolean flag = false
        for (Map.Entry<String, String> en : localVariableName.entrySet()) {
//            System.out.println("replaceMap 中 对应的   数据 -----" + en + "----" + en.getKey());
            if (newName.trim() == en.getValue().trim()) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                flag = true
                break
            }
        }
        if (flag) {
            return getNewString2();
        }
        return newName
    }

    Map<String, String> map = new HashMap<>();
/**
 * 先把 其他引用更改 在 后边 更改回来
 * @param line
 * @param sexg
 * @return
 */
    private String modificationLine(String line, String sexg) {
        Matcher matcher = line =~ sexg
        while (matcher.find()) {
            String oldResName = matcher.group(6)
            String newName = getNameAutomatically.getMultiLetter(5);
            line = line.replaceAll(oldResName, newName)
            map.put(newName, oldResName)
        }

        return line
    }

/**
 * 去除 其他 引用
 * @param line
 * @return
 */
    private String modificationStr(String line) {
        line = modificationLine(line, Constant.JAVA_REGEX)
        line = modificationLine(line, Constant.DRAWABLE_REGEX)
        line = modificationLine(line, Constant.ANIM_REGEX)
        line = modificationLine(line, Constant.STRING_REGEX)
        line = modificationLine(line, Constant.ID_REGEX)
        line = modificationLine(line, Constant.Id_REGEdsdX)
        return line
    }

}

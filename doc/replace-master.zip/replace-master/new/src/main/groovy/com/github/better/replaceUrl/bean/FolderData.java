package com.github.better.replaceUrl.bean;


import com.alibaba.fastjson2.annotation.JSONField;

import java.util.Date;
import java.util.List;

public class FolderData {

    @JSONField(format = "yyyy-MM-dd HH:mm:ss",name = "createTime")
    private Date createTime;
    @JSONField(name = "id")
    private String id;
    @JSONField(name = "moduleId")
    private String moduleId;
    @JSONField(name = "name")
    private String name;
    @JSONField(name = "projectId")
    private String projectId;
    @JSONField(name = "sort")
    private Integer sort;
    @JSONField(name = "children")
    private List<ChildrenDTO> children;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModuleId() {
        return moduleId;
    }

    public void setModuleId(String moduleId) {
        this.moduleId = moduleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public List<ChildrenDTO> getChildren() {
        return children;
    }

    public void setChildren(List<ChildrenDTO> children) {
        this.children = children;
    }



}

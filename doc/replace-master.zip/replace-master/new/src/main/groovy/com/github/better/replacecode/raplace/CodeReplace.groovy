package com.github.better.replacecode.raplace

import com.github.better.Constant
import com.github.better.replacecode.CodeNewConfiguration
import com.github.better.tools.GetNameAutomatically
import com.github.better.tools.StringUtils

import java.util.regex.Matcher

/**
 * 替换 全部 更改
 */
public class CodeReplace {

    GetNameAutomatically getNameAutomatically


    CodeReplace() {
        getNameAutomatically = GetNameAutomatically.getInstance(CodeNewConfiguration.getInstance())
    }
    Map<String, String> replaceMap;

    /**
     * 模板方法
     * @throws IOException
     */
    public void replaceThis(Map<String, String> replaceMap) throws IOException {
        this.replaceMap = replaceMap
        if (null == replaceMap || replaceMap.entrySet().size() == 0) {
            return
        }
        CodeNewConfiguration.srcFolderPath.each {
            replaceSrcDir(new File(it))
        }
        CodeNewConfiguration.resFolderPath.each {
            replaceSrcDir(new File(it))
        }
        CodeNewConfiguration.manifestFilePath.each {
            replaceSrcDir(new File(it))
        }
    }

    /**
     * 替换 src 源代码目录中的资源名
     * @param file 源代码目录
     * @param set 当前module下所有资源名 set
     * @param java_regx 匹配正则
     */
    private void replaceSrcDir(File file) {
        if (file.exists()) {
            if (file.isDirectory()) {
                file.eachFile { it -> replaceSrcDir(it) }
            } else {
                if (file.name.endsWith(".java") || file.name.endsWith(".xml") || file.name.endsWith(".kt")) {
                    // only .java or .kt files
                    handleSrcFile(file)
                }
            }
        }
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     * @param line
     * @return
     */
    private List<Map.Entry<String, String>> getString(String line) {
        List<Map.Entry<String, String>> map = new ArrayList<>()
        for (Map.Entry<String, String> en : replaceMap.entrySet()) {
            if (line.contains(en.key)) {
//                println "replaceMap 中 对应的 数据 -----" + en
                map.add(en)
            }
        }
        //根据 key 的长度 排序  长 --> 短
        Collections.sort(map, new Comparator<Map.Entry<String, String>>() {
            @Override
            int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
                if (o1.key.length() > o2.key.length()) {
                    return -1;
                } else if (o1.key.length() < o2.key.length()) {
                    return 1;
                }
                return 0
            }
        })

        return map
    }


    private void handleSrcFile(File file) {
        StringBuffer sb = new StringBuffer()
        String str = null
//        println "获取到的 数据 -----" + replaceMap.toString()
        file.eachLine("UTF-8") { line ->
//            println "获取到的 数据 -----" + line

            if (null != line && !StringUtils.isEs(line.toString())) {
                line = modificationStr(line)
                List<Map.Entry<String, String>> entry = getString(line)
//                println "for (i in 0..<entry.size()) {" +line
                for (i in 0..<entry.size()) {
                    Map.Entry<String, String> character = entry.get(i)
                    if (line.contains(character.key)) {
                        if(character.key.contains("(")){
//                            println "进入1 代码 ：character.key.contains(\"(\")" +character.toString()
                            line = StringUtils.replaceCharacter1(line, character.key, character.value)
                        }else{
//                            println "进入 2代码 ：character.key.contains(\"(\")" +character.toString()
                            line = StringUtils.replaceCharacter(line, character.key, character.value)
                        }
                        str = character.value
                    }
                }
                if (map.size() > 0) {
//                    println "在map中 找到的数据 --" +  map.toString()
                    for (Map.Entry<String, String> en : map.entrySet()) {
                        line = StringUtils.replaceCharacter(line, en.key, en.value);
                    }
                    map.clear()
                }
                entry.clear()
            }

//            println "替换后的 字符 -----" + line
            sb.append(line + "\r\n")
        }

        file.write(sb.toString(), "UTF-8")// 写回文件
    }

    Map<String, String> map = new HashMap<>();
    /**
     * 先把 其他引用更改 在 后边 更改回来
     * @param line
     * @param sexg
     * @return
     */
    private String modificationLine(String line, String sexg) {
        Matcher matcher = line =~ sexg
        while (matcher.find()) {
            String oldResName = matcher.group(6)
            String newName = getNameAutomatically.getMultiLetter(5);
            line = line.replaceAll(oldResName, newName)
            map.put(newName, oldResName)
        }

        return line
    }
    /**
     * 去除 其他 引用
     * @param line
     * @return
     */
    private String modificationStr(String line) {
        line = modificationLine(line, Constant.JAVA_REGEX)
        line = modificationLine(line, Constant.DRAWABLE_REGEX)
        line = modificationLine(line, Constant.ANIM_REGEX)
        line = modificationLine(line, Constant.STRING_REGEX)
        line = modificationLine(line, Constant.ID_REGEX)
        line = modificationLine(line, Constant.Id_REGEdsdX)

        return line
    }

    public static void main(String[] args) {
        String quantity = "@drawable/mifdjvteh_23100h";
        System.out.println(new CodeReplace().modificationStr(quantity));
//        System.out.println(frontCode1("B:dk_androidNew.YdSaas.Cashhole.app.build.intermediates.javac.androidcomDebug.classes.com.hole.bfl.bhim.bob.icic.lnoa.zidingyipackage.zidingyishurukuang$1.class", "com.hole.bfl.bhim.bob.icic.lnoa.zidingyipackage.zidingyishurukuang"));
    }

}

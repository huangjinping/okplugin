package com.github.better.replaceUrl.replace;

import com.github.better.replaceUrl.base.BaseUrlReplace;
import com.github.better.replaceUrl.bean.RequestArgsData;
import com.github.better.tools.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

/**
 * 代码 替换  替换
 */
public class CodeToReplace extends BaseUrlReplace {


    private Map<String, String> mBeadNameList;
    private Set<String> stringSet;


    RequestArgsData replaceUrlDate = null;
    int index = -1;

    @Override
    public String replaceStr(String str) {
        String str1 = str.replace("*", "").trim();
        if (StringUtils.isEs(str1)) {
            return str;
        }
        for (String str2 : stringSet) {
            if (str.contains("set" + StringUtils.toUpperCaseStr(str2)+"(")) {
                str = str.replace("set"+StringUtils.toUpperCaseStr(str2)+"(", "set"+StringUtils.toUpperCaseStr(mBeadNameList.get(str2))+"(");
            }

            if (str.contains("get" + StringUtils.toUpperCaseStr(str2)+"()")) {
                str = str.replace("get"+StringUtils.toUpperCaseStr(str2)+"()", "get"+StringUtils.toUpperCaseStr(mBeadNameList.get(str2))+"()");
            }

            if (str.contains("is" + StringUtils.toUpperCaseStr(str2)+"()")) {
                str = str.replace("is"+StringUtils.toUpperCaseStr(str2)+"()", "is"+StringUtils.toUpperCaseStr(mBeadNameList.get(str2))+"()");
            }

            if (str.contains("is" + StringUtils.toUpperCaseStr(str2.replace("is",""))+"()")) {
                str = str.replace("is"+StringUtils.toUpperCaseStr(str2)+"()", "is"+StringUtils.toUpperCaseStr(mBeadNameList.get(str2).replace("is",""))+"()");
            }
            if (str.contains("get" + StringUtils.toUpperCaseStr(str2.replace("is",""))+"()")) {
                str = str.replace("get"+StringUtils.toUpperCaseStr(str2)+"()", "get"+StringUtils.toUpperCaseStr(mBeadNameList.get(str2).replace("is",""))+"()");
            }
        }
        return str;
    }

    public void replaceCode(Map<String, String> mBeadNameList, ArrayList<String> listFileName) {
        this.mBeadNameList = mBeadNameList;
        this.stringSet = mBeadNameList.keySet();
        for (int i = 0; i < listFileName.size(); i++) {
            replaceSrcDir(new File(listFileName.get(i)));
        }
    }


}



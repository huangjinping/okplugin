package com.github.better.tools

import com.github.better.NewConfiguration

/**
 * 随机 字符串 类
 */
public class GetNameAutomatically {

    private static GetNameAutomatically instance;

    private NewConfiguration config;

    private Singleton() {

    }

    public static GetNameAutomatically getInstance(NewConfiguration config) {
        if (instance == null) {
            instance = new GetNameAutomatically();
        }
        instance.config = config;
        return instance;
    }
    /**
     * 获取随机 小写字母
     * @return
     */
    char getLetter() {
        return (char) (int) (Math.random() * 26 + 97)
    }
    /**
     * 获取随机 数字  0 -- 9
     * @return
     */
    int getNumber() {
        return (int) (Math.random() * 9)
    }

    /**
     * 获取 多个字母
     * @param size
     * @return
     */
    public String getMultiLetter(int size) {
        StringBuffer sb = new StringBuffer()
        for (i in 0..<size) {
            sb.append(getLetter())
        }
        return sb.toString()
    }
    /**
     * 获取 多个数字
     * @param size
     * @return
     */
    String getMultiNumber(int size) {
        StringBuffer sb = new StringBuffer()
        for (i in 0..<size) {
            sb.append(getNumber())
        }
        return sb.toString()
    }
    /**
     * 获取 随机命名
     * @return
     */
    String getAutomatically() {
        println("--------------- 命名规则：-------${config.namingScheme}")
        StringBuffer sb = new StringBuffer()
        String[] str = config.namingScheme.split("_")
        for (s in 0..<str.size()) {
            String str1 = str[s]
            //是否 包含数字规则
            if (str1.contains(NewConfiguration.RANDOM_NUMBER)) {
                String str2 = str1.substring(0, str1.indexOf(NewConfiguration.RANDOM_NUMBER))
                if (str2.matches("-?\\d+(\\.\\d+)?")) {
                    if (s == 0) {
                        sb.append(getMultiNumber(Integer.parseInt(str2)))
                    } else {
                        sb.append("_" + getMultiNumber(Integer.parseInt(str2)))
                    }
                } else {
                    if (s == 0) {
                        sb.append(getMultiNumber(1))
                    } else {
                        sb.append("_" + getMultiNumber(1))
                    }
                }
            } else if (str1.contains(NewConfiguration.RANDOM_LETTERS)) {
                String str2 = str1.substring(0, str1.indexOf(NewConfiguration.RANDOM_LETTERS))
                if (str2.matches("-?\\d+(\\.\\d+)?")) {
                    if (s == 0) {
                        sb.append(getMultiLetter(Integer.parseInt(str2)))
                    } else {
                        sb.append("_" + getMultiLetter(Integer.parseInt(str2)))
                    }
                } else {
                    if (s == 0) {
                        sb.append(getMultiLetter(1))
                    } else {
                        sb.append("_" + getMultiLetter(1))
                    }
                }
            } else {
                if (s == 0) {
                    sb.append(str1)
                } else {
                    sb.append("_" + str1)
                }
            }
        }
        println("--------------- 新的命名：-------${sb.toString()}")
        return sb.toString()
    }
}
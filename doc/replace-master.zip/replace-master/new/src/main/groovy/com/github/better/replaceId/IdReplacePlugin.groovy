package com.github.better.replaceId

import com.github.better.NewConfiguration
import com.github.better.tools.ConfigurationProcessing
import org.gradle.api.Project

/**
 * zhaoyu1
 */
class IdReplacePlugin {
    public void startPlugin(Project project) {
        //添加 config
        project.extensions.create('replaceIdConfig', NewConfiguration.class)
        //替换 布局 id 相关数据
        project.tasks.create(["name": "replaceId", "group": "resourceTools"]) {
            doLast {
                if (!project.android) {
                    throw new IllegalStateException('Must apply \'com.android.application\' or \'com.android.library\' first!')
                }

                if (project.replaceIdConfig == null) {       // check config
                    throw new IllegalArgumentException(
                            'replaceRes gradle plugin "resConfig DSL" config can not be null.')
                }
                long startTime = System.currentTimeMillis()     // startTime

                // === User settings


                def config = project.replaceIdConfig
                if (config.namingScheme == null || config.namingScheme.trim().length() == 0) {
                    throw new IllegalArgumentException(
                            'the [namingScheme] can not be null (必须配置 id  命名规则)')
                }
                String[] str = config.namingScheme.split("_")
                if (str[0].contains(NewConfiguration.RANDOM_NUMBER)) {
                    throw new IllegalArgumentException(
                            'The first line cannot be a number (第一行不能为数字)')
                }

                NewConfiguration.init(ConfigurationProcessing.getResAdders(project, config.processingModule), ConfigurationProcessing.getSrcAdders(project, config.processingModule), config.namingScheme)
                println "++++++++ 赋值完成 ..."
                new com.github.better.replaceId.folder.LayoutReplace().replaceThis()

                println("++++++++++++++++++++++ Finish replace resouces name, Total time: ${(System.currentTimeMillis() - startTime) / 1000} ")
            }
        }
    }
}
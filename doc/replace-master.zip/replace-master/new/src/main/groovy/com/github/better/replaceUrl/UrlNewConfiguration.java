package com.github.better.replaceUrl;

import com.github.better.NewConfiguration;
import com.github.better.tools.StringUtils;

public class UrlNewConfiguration extends NewConfiguration {
    /**
     * 接口文档目录
     */
    public static String urlTextPath = "";

    /**
     * 接口 类  全名
     *
     * @param urlTextPath
     */
    public static String apiClass = "";

    /**
     * api url 方法
     * 设置时 增加 （前缀 后缀）
     */
    public static String apiUrlMethodName = "api_";
    /**
     * view  调取 接口的 方法
     * 设置时 增加 （前缀 后缀）
     */
    public static String urlPgetMethodName = "get_";
    /**
     * url Result方法
     * 设置时 增加 （前缀 后缀）
     */
    public static String urlResultMethodName = "_Result";

    /**
     * url Error Result方法
     * 设置时 增加 （前缀 后缀）
     */
    public static String urlErrorResultMethodName = "_Error";

    /**
     * mvp 中调取 接口的 变量
     */
    public static String viewMethodName = "mView";


    /**
     * api url 方法
     * 设置时 增加 （前缀 后缀）
     */
    public static String apiUrlBeanName = "_Bean";


    public static void init(String urlTextPaths, String apiClasss) {
        urlTextPath = urlTextPath;
        apiClass = apiClass;
    }

    public static void init(String urlTextPaths, String apiClasss, String javaPaths, String apiUrlMethodNames, String urlPgetMethodNames, String urlResultMethodNames, String urlErrorResultMethodNames, String viewMethodNames, String apiUrlBeanNames) {
        urlTextPath = urlTextPath;
        apiClass = apiClasss;
//        srcFolderPath = javaPaths;
        if (!StringUtils.isEs(apiUrlMethodNames)) {
            apiUrlMethodName = apiUrlMethodNames;
        }

        if (!StringUtils.isEs(urlPgetMethodNames)) {
            urlPgetMethodName = urlPgetMethodNames;
        }

        if (!StringUtils.isEs(urlResultMethodNames)) {
            urlResultMethodName = urlResultMethodNames;
        }

        if (!StringUtils.isEs(urlErrorResultMethodNames)) {
            urlErrorResultMethodName = urlErrorResultMethodNames;
        }

        if (!StringUtils.isEs(viewMethodNames)) {
            viewMethodName = viewMethodNames;
        }

        if (!StringUtils.isEs(apiUrlBeanNames)) {
            apiUrlBeanName = apiUrlBeanNames;
        }


    }
}

package com.github.better.replaceUrl.bean;


import com.alibaba.fastjson2.annotation.JSONField;

import java.io.Serializable;
import java.util.Date;

public class ChildrenDTO implements Serializable {
    @JSONField(name = "contentType")
    private String contentType;
    @JSONField(format = "yyyy-MM-dd HH:mm:ss",name = "createTime")
    private Date createTime;
    @JSONField(name = "dataType")
    private String dataType;
    @JSONField(name = "description")
    private String description;
//    @transient(name = "example")
//    private String example;
    @JSONField(name = "examplefolderId")
    private String folderId;
    @JSONField(name = "id")
    private String id;
    @JSONField(format = "yyyy-MM-dd HH:mm:ss",name = "lastUpdateTime")
    private Date lastUpdateTime;
    @JSONField(name = "moduleId")
    private String moduleId;
    @JSONField(name = "name")
    private String name;
    @JSONField(name = "projectId")
    private String projectId;
    @JSONField(name = "protocol")
    private String protocol;
    @JSONField(jsonDirect=true,name = "requestArgs")
    private String  requestArgs;
    @JSONField(jsonDirect=true,name = "requestHeaders")
    private String requestHeaders;
    @JSONField(name = "requestMethod")
    private String requestMethod;
    @JSONField(jsonDirect=true,name = "responseArgs")
    private String  responseArgs;
    @JSONField(name = "sort")
    private Integer sort;
    @JSONField(name = "status")
    private String status;
    @JSONField(name = "url")
    private String url;

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

//    public String getExample() {
//        return example;
//    }
//
//    public void setExample(String example) {
//        this.example = example;
//    }

    public String getRequestArgs() {
        return requestArgs;
    }

    public void setRequestArgs(String requestArgs) {
        this.requestArgs = requestArgs;
    }

    public String getResponseArgs() {
        return responseArgs;
    }

    public void setResponseArgs(String responseArgs) {
        this.responseArgs = responseArgs;
    }

    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(Date lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public String getModuleId() {
        return moduleId;
    }

    public void setModuleId(String moduleId) {
        this.moduleId = moduleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }


    public String getRequestHeaders() {
        return requestHeaders;
    }

    public void setRequestHeaders(String requestHeaders) {
        this.requestHeaders = requestHeaders;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }



    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "ChildrenDTO{" +
                "contentType='" + contentType + '\'' +
                ", createTime=" + createTime +
                ", dataType='" + dataType + '\'' +
                ", description='" + description + '\'' +
                ", folderId='" + folderId + '\'' +
                ", id='" + id + '\'' +
                ", lastUpdateTime=" + lastUpdateTime +
                ", moduleId='" + moduleId + '\'' +
                ", name='" + name + '\'' +
                ", projectId='" + projectId + '\'' +
                ", protocol='" + protocol + '\'' +
                ", requestArgs='" + requestArgs + '\'' +
                ", requestHeaders='" + requestHeaders + '\'' +
                ", requestMethod='" + requestMethod + '\'' +
                ", responseArgs='" + responseArgs + '\'' +
                ", sort=" + sort +
                ", status='" + status + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}

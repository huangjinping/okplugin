package com.github.better.replacecode.raplace

import com.github.better.replacecode.CodeNewConfiguration
import com.github.better.replacecode.NewStr
import com.github.better.tools.FileTools
import com.github.better.tools.StringUtils

/**
 * 文件名  替换
 */
public class FileNameReplace {


    /**
     * 新 老文件名 对应数据
     *
     * 旧文件名 - 新文件名
     */
    private Map<String, String> beanNameList = new HashMap<String, String>();


    /**
     * 文件重命名，处理各种文件的重命名
     */
    protected void renameFile(List<String> ReviseFilePath) {
        ReviseFilePath.each {
            def file = new File(it)
            renameFile(file)
        }
    }

    /**
     * 文件重命名，处理各种文件的重命名
     */
    protected void renameFile(File file) {
        String fileName = file.name
        println("--------------- 原有文件名：${fileName}")
        String newName;
        if (file.isFile()) {
            fileName = fileName.substring(0, fileName.lastIndexOf(".")).trim();
            newName = getNewString1(fileName)
        } else {
            newName = getNewString2()
        }
        beanNameList.put(fileName, newName)
        newName = file.name.replace(fileName, newName).trim();
        println("--------------- 新文件名：${newName}------ 旧文件名：${fileName}")
        if (!FileTools.rename(file, newName)) {
            println("--------------- ${file.name} 重命名失败！，请手动修改成：${newName}")
        }
    }
    /**
     * 获取 文件 新命名
     * @param oldFileName
     * @return
     */
    private String getNewString1(String oldFileName) {
        println("--------------- 文件名：${oldFileName}")
        String prefixAndSuffix = null
        if (null != CodeNewConfiguration.prefixs || CodeNewConfiguration.prefixs.size() > 0) {
//            println("---------------配置 后缀 前缀  ：${CodeNewConfiguration.prefixs.toString()}")
            for (Map.Entry<String, String> en : CodeNewConfiguration.prefixs.entrySet()) {
//                println("---------------配置 后缀 前缀  ：${en.toString()}")
                if (StringUtils.isEs(en.getValue())) {
                    prefixAndSuffix = en.getKey()
                } else {
                    if (en.getValue().startsWith("_")) {
                        if (oldFileName.endsWith(en.getValue().replace("_", ""))) {
                            prefixAndSuffix = en.getKey()
                        }
                    } else {
                        if (oldFileName.startsWith(en.getValue().replace("_", ""))) {
                            prefixAndSuffix = en.getKey()
                        }
                    }
                }
            }
        }
        String newName
        if (StringUtils.isEs(prefixAndSuffix)) {
            //设置 字符 首字母大写
            newName = NewStr.getInstance().getInitialsString()
        } else {
            if (prefixAndSuffix.startsWith("_")) {
                newName = NewStr.getInstance().getInitialsString() + prefixAndSuffix.replace("_", "")
            } else {
                newName = prefixAndSuffix.replace("_", "") + NewStr.getInstance().getInitialsString()
            }
        }
        boolean flag = false
        for (Map.Entry<String, String> en : beanNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的  数据 -----" + en + "----" + en.getKey());
            if (newName.trim() == en.getValue().trim()) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                flag = true
                break
            }
        }
        if (flag) {
            return getNewString1(oldFileName)
        }
        return newName;
    }

    private String getNewString2() {
        String newName = NewStr.getInstance().getAllLowercaseString()
        boolean flag = false
        for (Map.Entry<String, String> en : beanNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的   数据 -----" + en + "----" + en.getKey());
            if (newName.trim() == en.getValue().trim()) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                flag = true
                break
            }
        }
        if (flag) {
            return getNewString2();
        }
        return newName
    }


    private void folderHandling() {
        for (int i = 0; i < CodeNewConfiguration.ReviseFilePath.size(); i++) {
            def file = new File(CodeNewConfiguration.ReviseFilePath.get(i))
            if (file.isDirectory()) {
                renameFile(file)
                dataProcessing()
                CodeNewConfiguration.ReviseFilePath.remove(i)
                folderHandling()
                return
            } else {
                renameFile(file)
                CodeNewConfiguration.ReviseFilePath.remove(i)
                folderHandling()
                return
            }
        }
    }

    private void dataProcessing() {
        for (int i = 0; i < CodeNewConfiguration.ReviseFilePath.size(); i++) {
            for (Map.Entry<String, String> en : beanNameList.entrySet()) {
                System.out.println("replaceMap 中 对应的 " + CodeNewConfiguration.ReviseFilePath.get(i) + " 数据 -----" + en + "----" + en.getKey());
                if (CodeNewConfiguration.ReviseFilePath.get(i).contains("\\" + en.getKey().trim() + "\\")) {
                    System.out.println("replaceMap 中 成功的数据 -----" + en);
                    CodeNewConfiguration.ReviseFilePath.set(i, CodeNewConfiguration.ReviseFilePath.get(i).replace("\\" + en.getKey().trim() + "\\", "\\" + en.getValue().trim() + "\\"))
                    break
                }
            }
        }
    }

    public void replaceCode(Map<String, String> map) {
        if (null == CodeNewConfiguration.ReviseFilePath) {
            return
        }
        folderHandling()

        beanNameList.putAll(map)

        new CodeReplace().replaceThis(beanNameList);

    }
}


package com.github.better.tools;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class StringUtils {


    private static String basicType = "String,Boolean,Integer,Double";

    public static boolean isBasicType(String type) {
        return basicType.contains(type);
    }


    public static float levenshtein1(String str1, String str2) {
        if (str1.contains(str2) || str2.contains(str1)) {
            System.out.println("相似度：" + 1);
            return 1;
        }
        return levenshtein(str1, str2);
    }

    /**
     * 　　DNA分析 　　拼字检查 　　语音辨识 　　抄袭侦测
     *
     * @createTime 2012-1-12
     */
    public static float levenshtein(String str1, String str2) {
        if (isEs(str1) || isEs(str2)) {
            return 0;
        }
        str1 = str1.replaceAll(" ", "");
        str2 = str2.replaceAll(" ", "");
        str2 = removeCode(str2);
//        System.out.println("字符串\"" + str1 + "\"与\"" + str2 + "\"的比较");

//        System.out.println("字符串\"" + str1 + "\"与\"" + str2 + "\"的比较");
        if (isEs(str1) || isEs(str2)) {
            return 0;
        }
//        if (str1.contains(str2) || str2.contains(str1)) {
//            System.out.println("相似度：" + 1);
//            return 1;
//        }
        //计算两个字符串的长度。
        int len1 = str1.length();
        int len2 = str2.length();
        //建立上面说的数组，比字符长度大一个空间
        int[][] dif = new int[len1 + 1][len2 + 1];
        //赋初值，步骤B。
        for (int a = 0; a <= len1; a++) {
            dif[a][0] = a;
        }
        for (int a = 0; a <= len2; a++) {
            dif[0][a] = a;
        }
        //计算两个字符是否一样，计算左上的值
        int temp;
        for (int i = 1; i <= len1; i++) {
            for (int j = 1; j <= len2; j++) {
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    temp = 0;
                } else {
                    temp = 1;
                }
                //取三个值中最小的
                dif[i][j] = min(dif[i - 1][j - 1] + temp, dif[i][j - 1] + 1,
                        dif[i - 1][j] + 1);
            }
        }

        //取数组右下角的值，同样不同位置代表不同字符串的比较
//        System.out.println("差异步骤：" + dif[len1][len2]);
        //计算相似度
        float similarity = 1 - (float) dif[len1][len2] / Math.max(str1.length(), str2.length());


        if (similarity > 0.5) {
            System.out.println("字符串对比相似度：" + similarity);
        }
        return similarity;
    }

    /**
     * 转义正则特殊字符 （$()*+.[]?\^{}
     * \\需要第一个替换，否则replace方法替换时会有逻辑bug
     */
    public static String makeQueryStringAllRegExp(String str) {
        if (isEs(str)) {
            return str;
        }

        return str.replace("\\", "\\\\").replace("*", "\\*")
                .replace("+", "\\+").replace("|", "\\|")
                .replace("{", "\\{").replace("}", "\\}")
                .replace("(", "\\(").replace(")", "\\)")
                .replace("^", "\\^").replace("$", "\\$")
                .replace("[", "\\[").replace("]", "\\]")
                .replace("?", "\\?").replace(",", "\\,")
                .replace(".", "\\.").replace("&", "\\&");
    }

    /**
     * 替换 字符
     * <p>
     * 判断 字符串 前后 是否是 字母  或 数字  ： 有 （不替换）  无 ： 替换
     */
    public static String replaceCharacter(String str, String str1, String str2) {
        int v = countStr(str, str1);
        if (v == 1) {
            if (!frontCode(str, str1)) {
                return str.replaceAll(makeQueryStringAllRegExp(str1), makeQueryStringAllRegExp(str2));
            }
        } else {
            String[] str3Lists = str.split(str1);
            for (int i = 0; i < str3Lists.length - 1; i++) {
                String str3 = str3Lists[i] + str1 + str3Lists[i + 1];
                if (!frontCode(str3, str1)) {
                    String str4 = str3.replaceAll(str1, str2);
                    str = str.replaceAll(makeQueryStringAllRegExp(str3), makeQueryStringAllRegExp(str4));
                }
            }
        }
        return str;
    }

    /**
     * 替换 字符
     * <p>
     * 判断 字符串 前后 是否是 字母  或 数字  ： 有 （不替换）  无 ： 替换
     * <p>
     * 只 校验 前边是否 是 字母  或 数字
     */
    public static String replaceCharacter1(String str, String str1, String str2) {
        int v = countStr(str, str1);
//        System.out.println("1111111111111111str.replaceAll(makeQueryStringAllRegExp(str1)" + str1);
        if (v == 1) {
//            System.out.println("222222222222222222222str.replaceAll(makeQueryStringAllRegExp(str1)" + str1);
            if (!frontCode2(str, str1)) {
//                System.out.println("str.replaceAll(makeQueryStringAllRegExp(str1)" + str1 + "------" + str2);
                return str.replaceAll(makeQueryStringAllRegExp(str1), makeQueryStringAllRegExp(str2));
            }
        } else {
//            System.out.println("333333333.replaceAll(makeQueryStringAllRegExp(str1)" + str1);
            String[] str3Lists = str.split(makeQueryStringAllRegExp(str1));
            for (int i = 0; i < str3Lists.length - 1; i++) {
                String str3 = str3Lists[i] + str1 + str3Lists[i + 1];
                if (!frontCode2(str3, str1)) {
//                    System.out.println("444444.replaceAll(makeQueryStringAllRegExp(str1)" + str1);
                    String str4 = str3.replaceAll(makeQueryStringAllRegExp(str1), makeQueryStringAllRegExp(str2));
//                    System.out.println("str.replaceAll(makeQueryStringAllRegExp(str3)" + str3 + "------" + str3);
                    str = str.replaceAll(makeQueryStringAllRegExp(str3), makeQueryStringAllRegExp(str4));
                }
            }
        }
        return str;
    }

    public static void main(String[] args) {
//        int quantity = 3;
//        System.out.println(quantity % 2 + "");
        String dsd = "abstract static interface";
        String dckks = "interface";

        System.out.println(dsd.contains(dckks));
//        System.out.println(frontCode1("B:dk_androidNew.YdSaas.Cashhole.app.build.intermediates.javac.androidcomDebug.classes.com.hole.bfl.bhim.bob.icic.lnoa.zidingyipackage.zidingyishurukuang$1.class", "com.hole.bfl.bhim.bob.icic.lnoa.zidingyipackage.zidingyishurukuang"));
    }

    /**
     * 判断 字符串 前后 是否是 字母  或 数字  或 _ 下划线
     *
     * @return true 是   false 不是
     */
    private static boolean frontCode(String str, String str1) {
        if (str.equals(str1)) {
            return false;
        }
        if (str.contains(str1)) {
            boolean flag = true;
            boolean flag1 = true;
            int i = str.indexOf(str1);
            if (i != 0) {
                String str2 = str.substring(i - 1, i);
                if (!isNumeric2(str2) && !check(str2) && !str2.equals("_")) {
                    flag = false;
                }
            } else {
                flag = false;
            }
            if (i + str1.length() < str.length()) {
                String str2 = str.substring(i + str1.length(), i + str1.length() + 1);
                if (!isNumeric2(str2) && !check(str2) && !str2.equals("_")) {
                    flag1 = false;
                }
            } else {
                flag1 = false;
            }
            if (flag || flag1) {
                return true;
            }
        } else {
            return false;
        }
        return false;

    }

    /**
     * 判断 字符串 前后 是否是 字母  或 数字  或 _ 下划线  $
     *
     * @return true 是   false 不是
     */
    private static boolean frontCode1(String str, String str1) {


        if (str.equals(str1)) {
            return false;
        }
        if (str.contains(str1)) {
            boolean flag = true;
            boolean flag1 = true;
            int i = str.indexOf(str1);
            if (i != 0) {
                String str2 = str.substring(i - 1, i);
                if (!isNumeric2(str2) && !check(str2) && !str2.equals("_") && !str2.equals("$")) {
                    flag = false;
                }
            } else {
                flag = false;
            }
            if (i + str1.length() < str.length()) {
                String str2 = str.substring(i + str1.length(), i + str1.length() + 1);
                if (!isNumeric2(str2) && !check(str2) && !str2.equals("_") && !str2.equals("$")) {
                    flag1 = false;
                }
            } else {
                flag1 = false;
            }
            if (flag || flag1) {
                return true;
            }
        } else {
            return false;
        }
        return false;

    }

    /**
     * 判断 字符串 前 是否是 字母  或 数字  或 _ 下划线
     *
     * @return true 是   false 不是
     */
    private static boolean frontCode2(String str, String str1) {
        if (str.equals(str1)) {
            return false;
        }
        if (str.contains(str1)) {
            boolean flag = true;
            int i = str.indexOf(str1);
            if (i != 0) {
                String str2 = str.substring(i - 1, i);
                if (!isNumeric2(str2) && !check(str2) && !str2.equals("_")) {
                    flag = false;
                }
            } else {
                flag = false;
            }
            if (flag) {
                return true;
            }
        } else {
            return false;
        }
        return false;

    }


    /**
     * 去除 代码 //  留 注释
     *
     * @return
     */
    private static String removeCode(String str) {
        if (str.contains(";")) {
            str = str.substring(str.lastIndexOf(";") + 1, str.length());
        }
        if (str.contains("//")) {
            str = str.substring(str.lastIndexOf("//") + 2, str.length());
        }
        if (str.contains("*")) {
            str = str.substring(str.lastIndexOf("*") + 1, str.length());
        }
        return str;
    }

    //得到最小值
    private static int min(int... is) {
        int min = Integer.MAX_VALUE;
        for (int i : is) {
            if (min > i) {
                min = i;
            }
        }
        return min;
    }

    /**
     * 都是 截取 最后 出现的位置   并替换
     *
     * @param s
     * @param d
     * @param str
     * @return
     */
    public static String cutOutReplace(String s, String d, String str, String str1) {
        String s1 = str.substring(str.lastIndexOf(s) + s.length(), str.lastIndexOf(d));
//        System.out.println(s1);
        return str.replace(s1, str1);
    }

    /**
     * 都是 截取 最后 出现的位置
     *
     * @param s
     * @param d
     * @param str
     * @return
     */
    public static String getStringFrom(String s, String d, String str) {
        return str.substring(str.lastIndexOf(s) + s.length(), str.lastIndexOf(d));
    }

    /**
     * 最后 出现位置   ------ 第一次 出现的位置
     *
     * @param s
     * @param d
     * @param str
     * @return
     */
    public static String getStringFrom2(String s, String d, String str) {
        int iw = str.lastIndexOf(s) + s.length();
        int ed = str.indexOf(d);
        if (iw < ed) {
            return str.substring(iw, ed);
        } else {
            return null;
        }

    }

    /**
     * 第一次 出现 位置   ------ 最后 出现位置
     *
     * @param s
     * @param d
     * @param str
     * @return
     */
    public static String getStringFrom3(String s, String d, String str) {
        if (StringUtils.isEs(str)) {
            return null;
        }
        int iw = str.indexOf(s) + s.length();
        int ed = str.lastIndexOf(d);
        if (iw < ed) {
            return str.substring(iw, ed);
        } else {
            return null;
        }
    }

    public static String getStringFrom4(String s, String d, String str) {
        int iw = str.indexOf(s) + s.length();
        int ed = str.indexOf(d);
        if (iw < ed) {
            return str.substring(iw, ed);
        } else {
            return null;
        }
    }


    /**
     * 判断str1中包含str2的个数
     *
     * @param str1
     * @param str2
     * @return counter
     */
    public static int countStr(String str1, String str2) {
        int count = 0, len = str1.length();
        while (str1.indexOf(str2) != -1) {
            str1 = str1.substring(str1.indexOf(str2) + 1, str1.length());
            count++;
        }
        return count;
    }

    private static final Pattern NUMBER_PATTERN = Pattern.compile("-?\\d+(\\.\\d+)?");


    /**
     * 是否 为 数字
     *
     * @param str
     * @return
     */
    public static boolean isNumeric2(String str) {
        return str != null && NUMBER_PATTERN.matcher(str).matches();
    }

    /**
     * 首字母大写
     */
    public static String toUpperCaseStr(String name) {
        return name.substring(0, 1).toUpperCase() + name.substring(1);//UpperCase大

    }


    /**
     * 首字母小写
     */
    public static String toLowerCaseStr(String name) {
        name = name.substring(0, 1).toLowerCase() + name.substring(1);//UpperCase大写
        return name;

    }

    public static boolean isEs(String str) {
        if (null == str) {
            return true;
        } else if (str.length() == 0) {
            return true;
        } else if (" ".equals(str)) {
            return true;
        }
        return false;
    }

    /**
     * 判断一个字符串是否为字母
     */
    public static boolean check(String fstrData) {
        char c = fstrData.charAt(0);

        if (((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {
            return true;

        } else {
            return false;

        }

    }

    /**
     * 去除 特殊字符
     *
     * @param fstrData
     * @return
     */
    public static String removeSpecialCharacters(String fstrData) {
        //1. 可以在中括号内加上任何想要删除的字符，实际上是一个正则表达式
        String regExp = "[\n`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。， 、？]";

        //2. 这里是将特殊字符换为空字符串,""代表直接去掉
        String replace = "";
        return fstrData.replaceAll(regExp, replace);
    }

    /**
     * 去除 String[] 数组中的空字符串("")
     *
     * @param arr 源数组
     * @return 操作后的新数组 String[]
     */
    public static String[] removeArraysEmpty1(String[] arr) {
        return Arrays.stream(arr).filter(s -> !"".equals(s)).toArray(String[]::new);
    }

    /**
     * 去除 String[] 数组中的空字符串("")
     *
     * @param arr 源数组
     * @return 操作后的新列表 List<>
     */
    public static List<String> removeArraysEmpty2(String[] arr) {
        return Arrays.stream(arr).filter(s -> !"".equals(s)).collect(Collectors.toList());
    }

    /**
     * 去除 String[] 数组中的空值(null)
     *
     * @param arr 源数组
     * @return 操作后的新数组 String[]
     */
    public static String[] removeArraysEmpty3(String[] arr) {
        return Arrays.stream(arr).filter(Objects::nonNull).toArray(String[]::new);
    }

    /**
     * 去除 String[] 数组中的空值(null)
     *
     * @param arr 源数组
     * @return 操作后的新列表 List<>
     */
    public static List<String> removeArraysEmpty4(String[] arr) {
        return Arrays.stream(arr).filter(Objects::nonNull).collect(Collectors.toList());
    }

    /**
     * 字符串 分段  “ ”分割
     */
    public static String[] stringSegmentation(String arr) {
        String[] sd = arr.trim().split(" ");
        sd = removeArraysEmpty1(sd);
        sd = removeArraysEmpty3(sd);
        return sd;
    }

    /**
     * 分析
     */
    public static String stringMatch(String arr, String name) {
        if (!name.contains(",")) {
            return null;
        }
        System.out.println("stringMatch  字符串\"" + arr + "\"与\"" + name + "\"的比较");
        String[] sd = name.split(",");
        if (arr.contains(sd[0]) && !frontCode(arr, sd[0])) {
            return sd[1];
        } else if (arr.contains(sd[1]) && !frontCode(arr, sd[1])) {
            return sd[0];
        }
        return null;
    }

    public static int stringMatch2(String arr, String name) {

        if (!name.contains(",")) {
            return 0;
        }
//        System.out.println("stringMatch2  字符串\"" + arr + "\"与\"" + name + "\"的比较");
        if (arr.contains("private") && arr.contains(";")) {
            String[] sd = name.split(",");
            if (arr.contains(sd[0]) && !frontCode(arr, sd[0])) {
                return 1;
            } else if (arr.contains(sd[1]) && !frontCode(arr, sd[1])) {
                return 1;
            }
        }
        return 0;
    }


    public static String stringMatch1(String name1, String name2) {
        name1 = name1.trim();
        if (!name2.contains(",")) {
            return name2;
        }
//        System.out.println("stringMatch1  字符串\"" + name1 + "\"与\"" + name2 + "\"的比较");
        String[] sd = name2.split(",");
        if (name1.contains(sd[0].trim()) && !frontCode(name1, sd[0])) {
            return sd[1];
        } else if (name1.contains(sd[1].trim()) && !frontCode(name1, sd[1])) {
            return sd[0];
        }
        return sd[0];
    }
}
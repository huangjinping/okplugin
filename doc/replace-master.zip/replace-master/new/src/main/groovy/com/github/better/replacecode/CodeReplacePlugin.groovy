package com.github.better.replacecode

import com.github.better.replacecode.CodeNewConfiguration
import com.github.better.replacecode.raplace.ClassReplace
import com.github.better.tools.ConfigurationProcessing
import org.gradle.api.Project

/**
 * 资源名 修改
 */
class CodeReplacePlugin {

    public void startPlugin(Project project) {
        //添加 config
        project.extensions.create('replaceCodeConfig', CodeNewConfiguration.class)
        //替换 资源 名称
        project.tasks.create(["name": "replaceCode", "group": "resourceTools"]) {
            doLast {
                long startTime = System.currentTimeMillis()     // startTime
                if (!project.android) {
                    throw new IllegalStateException('Must apply \'com.android.application\' or \'com.android.library\' first!')
                }

                if (project.resConfig == null) {       // check config
                    throw new IllegalArgumentException(
                            'replaceRes gradle plugin "resConfig DSL" config can not be null.')
                }
                println(">>>>>> old_prefix: 代码替换 程序")
                // === User settings
                def config = project.replaceCodeConfig
                if (config.ReviseFilePath == null || config.ReviseFilePath.size() == 0) {
                    throw new IllegalArgumentException(
                            'the [namingScheme] can not be null (文件重命名路径)')
                }


                println(">>>>>> old_prefix: ${config.prefixs}")
//                println(">>>>>> new_prefix: ${config.new_prefix}")
//                println(">>>>>> srcFolder : ${sourceFolder}")
//                println(">>>>>> resFolder : ${resFolder}")
//                println(">>>>>> AndroidManifest.xml file path : ${manifestFilePath}")
//                println(">>>>>> addrts file path : ${assetsFilePath}")

                // === do work
                println "++++++++++++++++++++++ Start replace Android resources..."

                List<String> classFileList = ConfigurationProcessing.getCalssPath(project, config.ReviseFilePath)
                if (classFileList.size() > 0) {
                    CodeNewConfiguration.init(
                            config.prefixs,
                            ConfigurationProcessing.getSrcAdders(project, config.processingModule),
                            ConfigurationProcessing.getResAdders(project, config.processingModule),
                            ConfigurationProcessing.getManifestAdders(project, config.processingModule),
                            ConfigurationProcessing.getFullPath(project, config.ReviseFilePath),
                            classFileList
                    )
//                new FileNameReplace().replaceCode()
                    new ClassReplace().replaceThis()
                } else {
                    println("************build 没有数据，class 编译后数据没有******************")
                }


                println("++++++++++++++++++++++ Finish replace resouces name, Total time: ${(System.currentTimeMillis() - startTime) / 1000} ")
            }
        }
    }


}
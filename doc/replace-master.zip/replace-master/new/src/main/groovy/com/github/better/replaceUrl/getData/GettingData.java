package com.github.better.replaceUrl.getData;


import com.alibaba.fastjson2.*;
import com.github.better.replaceUrl.bean.BaseData;
import com.github.better.replaceUrl.bean.ChildrenDTO;
import com.github.better.replaceUrl.bean.EnvironmentsData;
import com.github.better.replaceUrl.bean.FolderData;
import com.github.better.replaceUrl.bean.RequestArgsData;
import com.github.better.replaceUrl.bean.UrlDate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import groovy.json.StringEscapeUtils;

public class GettingData {

    public static void main(String[] args) {
        String path = "B:\\replace\\3qyNVscvO.mjson";
        List<UrlDate> list =   new GettingData().getUrlTxt(path);
    }

    public List<UrlDate> getUrlTxt(String path) {
        JSONReader reader = null;
        BaseData.ProjectDTO vo = null;
        List<BaseData.ModulesDTO> list = null;
        try {
            File jsonFile = new File(path);
            Reader readerd = new InputStreamReader(new FileInputStream(jsonFile), "utf-8");
            reader = JSONReader.of(readerd);

            Map<String, Object> modul =  reader.readObject();

//            System.out.println("json  字符串----" + reader.toString());

            String jsonString = StringEscapeUtils.unescapeJava(modul.get("project").toString());
            jsonString = jsonString
                    .replaceAll("}]\"", "}]")
                    .replaceAll("\"\\[\\{", "[{");
            vo = JSON.parseObject(jsonString, BaseData.ProjectDTO.class);
            System.out.println("接口 文档 名称  >>>>>>>>>----" + vo.getName());


            list = JSON.parseArray(modul.get("modules").toString(), BaseData.ModulesDTO.class);


            // handle vo ...
            reader.close();
        } catch (FileNotFoundException |
                UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        if (null == vo || null == list) {
//            System.out.println("json  字符串----   解析 错误 ");
            return null;
        }


        return getUrlTxtlll(vo, list);

    }

    /**
     * 获取 url 文档数据
     *
     * @return
     */
    public List<UrlDate> getUrlTxtlll(BaseData.ProjectDTO vo, List<BaseData.ModulesDTO> list) {
        List<UrlDate> allList = new ArrayList<>();

        for (int i = 0; i < list.size(); i++) {
            List<FolderData> folderDataList = list.get(i).getFolders();

            for (int j = 0; j < folderDataList.size(); j++) {
                List<ChildrenDTO> childrenDTOList = folderDataList.get(j).getChildren();
                for (int k = 0; k < childrenDTOList.size(); k++) {
                    ChildrenDTO childrenDTO = childrenDTOList.get(k);
//                    System.out.println(childrenDTO.toString());
                    UrlDate urlDate = new UrlDate();
                    int index = childrenDTO.getUrl().lastIndexOf("$");

                    String url = null;
                    if (index != -1) {
                        String baseUrl = getBaseUsrl(childrenDTO.getUrl().substring(1, index), vo.getEnvironments());
                        url = baseUrl + childrenDTO.getUrl().substring(index + 1);
                    } else {
                        url = childrenDTO.getUrl();
                    }
                    urlDate.setUrl(url);
                    urlDate.setName(childrenDTO.getName());
                    urlDate.setRequestArgs(analysisRequest(childrenDTO.getRequestArgs()));
                    urlDate.setResponseArgs(analysisRequest(childrenDTO.getResponseArgs()));
                    allList.add(urlDate);

                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                    System.out.println(urlDate.getName() + "---- 更新时间 >>>>>>>>>>>>" + sdf.format(childrenDTO.getLastUpdateTime()));
                }
            }
        }
//        System.out.println(allList.toString());
        return allList;
    }

    /**
     * 进一步 解析 返回值  入参
     */
    private List<RequestArgsData> analysisRequest(String jsonString) {
        jsonString = jsonString
                .replaceAll("}]\"", "}]")
                .replaceAll("\"\\[\\{", "[{");

//        System.out.println("处理后 的数据 " + jsonString);
        return JSON.parseArray(jsonString, RequestArgsData.class);
    }

    /**
     * 获取 url  前边包名
     *
     * @param name
     * @param e
     * @return
     */
    private String getBaseUsrl(String name, List<EnvironmentsData> e) {
        String str = "";
        for (int i = 0; i < e.size(); i++) {
            for (int j = 0; j < e.get(i).getVars().size(); j++) {
                EnvironmentsData.VarsDTO varsDTO = e.get(i).getVars().get(j);
//                System.out.println("name ------------------------------" + name);

//                System.out.println("varsDTO ------------------" + varsDTO);
                if (name.equalsIgnoreCase(varsDTO.getName())) {
                    str = varsDTO.getValue().substring(varsDTO.getValue().lastIndexOf("9527/") + 5);
                }
            }
        }
//        System.out.println("获取到的 接口包名 ---------------------------" + str);
        return str;
    }
}
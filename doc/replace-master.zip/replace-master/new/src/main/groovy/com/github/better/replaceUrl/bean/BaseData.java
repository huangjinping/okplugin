package com.github.better.replaceUrl.bean;


import com.alibaba.fastjson2.annotation.JSONField;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class BaseData {

    @JSONField(name = "project")
    private ProjectDTO project;
    @JSONField(name = "modules")
    private List<ModulesDTO> modules;

    public ProjectDTO getProject() {
        return project;
    }

    public void setProject(ProjectDTO project) {
        this.project = project;
    }

    public List<ModulesDTO> getModules() {
        return modules;
    }

    public void setModules(List<ModulesDTO> modules) {
        this.modules = modules;
    }

    public static class ProjectDTO implements Serializable {
        @JSONField(format = "yyyy-MM-dd HH:mm:ss", name = "createTime")
        private Date createTime;
        @JSONField(name = "description")
        private String description;
        @JSONField(name = "details")
        private String details;
        @JSONField(name = "editable")
        private String editable;
        @JSONField(name = "environments")
        private List<EnvironmentsData> environments;
        @JSONField(name = "id")
        private String id;
        @JSONField(name = "name")
        private String name;
        @JSONField(name = "permission")
        private String permission;
        @JSONField(name = "status")
        private String status;
        @JSONField(name = "userId")
        private String userId;

        public Date getCreateTime() {
            return createTime;
        }

        public void setCreateTime(Date createTime) {
            this.createTime = createTime;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getDetails() {
            return details;
        }

        public void setDetails(String details) {
            this.details = details;
        }

        public String getEditable() {
            return editable;
        }

        public void setEditable(String editable) {
            this.editable = editable;
        }


        public List<EnvironmentsData> getEnvironments() {
            return environments;
        }

        public void setEnvironments(List<EnvironmentsData> environments) {
            this.environments = environments;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPermission() {
            return permission;
        }

        public void setPermission(String permission) {
            this.permission = permission;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        @Override
        public String toString() {
            return "ProjectDTO{" +
                    "createTime=" + createTime +
                    ", description='" + description + '\'' +
                    ", details='" + details + '\'' +
                    ", editable='" + editable + '\'' +
                    ", environments='" + environments + '\'' +
                    ", id='" + id + '\'' +
                    ", name='" + name + '\'' +
                    ", permission='" + permission + '\'' +
                    ", status='" + status + '\'' +
                    ", userId='" + userId + '\'' +
                    '}';
        }
    }

    public static class ModulesDTO implements Serializable {
        @JSONField(format = "yyyy-MM-dd HH:mm:ss", name = "createTime")
        private Date createTime;
        @JSONField(name = "id")
        private String id;
        @JSONField(format = "yyyy-MM-dd HH:mm:ss", name = "lastUpdateTime")
        private Date lastUpdateTime;
        @JSONField(name = "name")
        private String name;
        @JSONField(name = "projectId")
        private String projectId;
//        @JSONField(jsonDirect = true, name = "requestArgs")
//        private String requestArgs;
//        @JSONField(jsonDirect = true, name = "requestHeaders")
//        private String requestHeaders;
        @JSONField(name = "folders")
        private List<FolderData> folders;

        public Date getCreateTime() {
            return createTime;
        }

        public void setCreateTime(Date createTime) {
            this.createTime = createTime;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Date getLastUpdateTime() {
            return lastUpdateTime;
        }

        public void setLastUpdateTime(Date lastUpdateTime) {
            this.lastUpdateTime = lastUpdateTime;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getProjectId() {
            return projectId;
        }

        public void setProjectId(String projectId) {
            this.projectId = projectId;
        }

//        public String getRequestArgs() {
//            return requestArgs;
//        }
//
//        public void setRequestArgs(String requestArgs) {
//            this.requestArgs = requestArgs;
//        }
//
//        public String getRequestHeaders() {
//            return requestHeaders;
//        }
//
//        public void setRequestHeaders(String requestHeaders) {
//            this.requestHeaders = requestHeaders;
//        }

        public List<FolderData> getFolders() {
            return folders;
        }

        public void setFolders(List<FolderData> folders) {
            this.folders = folders;
        }

        @Override
        public String toString() {
            return "ModulesDTO{" +
                    "createTime=" + createTime +
                    ", id='" + id + '\'' +
                    ", lastUpdateTime=" + lastUpdateTime +
                    ", name='" + name + '\'' +
                    ", projectId='" + projectId + '\'' +
//                    ", requestArgs='" + requestArgs + '\'' +
//                    ", requestHeaders='" + requestHeaders + '\'' +
                    ", folders=" + folders +
                    '}';
        }
    }


    @Override
    public String toString() {
        return "BaseData{" +
                "project=" + project +
                ", modules=" + modules +
                '}';
    }
}

package com.github.better.replaceRes.base

import com.github.better.replaceRes.ResNewConfiguration
import com.github.better.tools.GetNameAutomatically
import com.github.better.tools.StringUtils

import java.util.regex.Matcher

abstract class BaseReplace {


    Map<String, String> replaceMap = new HashMap<>()

    // ====== 源代码中的部分  start =============================================
    /**
     * 替换 src 源代码目录中的资源名
     * @param file 源代码目录
     * @param set 当前module下所有资源名 set
     * @param java_regx 匹配正则
     */
    protected void replaceSrcDir(List<String> fileNameList, Set<String> set, java_regx) {
        fileNameList.each { filename ->
            File file = new File(filename)
            if (file.exists()) {
                if (file.isDirectory()) {
                    file.eachFile { it ->
                        replaceSrcDir(it, set, java_regx)

                    }
                } else {
                    if (file.name.endsWith(".java") || file.name.endsWith(".kt")) {
                        // only .java or .kt files
                        handleSrcFile(file, set, java_regx)
                    }
                }
            }
        }
    }

    protected void replaceSrcDir(File file, Set<String> set, java_regx) {
        if (file.exists()) {
            if (file.isDirectory()) {
                file.eachFile { it -> replaceSrcDir(it, set, java_regx) }
            } else {
                if (file.name.endsWith(".java") || file.name.endsWith(".kt")) {
                    // only .java or .kt files
                    handleSrcFile(file, set, java_regx)
                }
            }
        }
    }

    def handleSrcFile(File file, Set<String> set, regex) {
        String fileContent = file.getText("UTF-8")              // every file is a text file
        StringBuffer sb = new StringBuffer()             // result content
        Matcher matcher = fileContent =~ regex
        while (matcher.find()) {
            String oldResName = matcher.group(6)   // the old res name
            if (set.contains(oldResName)) {               // 本模块中包含的资源名，才替换
                String newResName
                if (!StringUtils.isEs(ResNewConfiguration.getInstance().namingScheme)) {
                    println("--------------- Java 旧名字 ：${oldResName}-------")
                    String str = lookingMatch(oldResName)
                    if (!StringUtils.isEs(str)) {
                        matcher.appendReplacement(sb, "\$1$str") // 拼接 保留$1分组,替换$6分组
                    }
                } else if (!StringUtils.isEs(ResNewConfiguration.old_prefix) && oldResName.contains(ResNewConfiguration.old_prefix)) {
                    // 替换掉旧的前缀
                    newResName = ResNewConfiguration.new_prefix + oldResName.substring(ResNewConfiguration.old_prefix.length())
                    matcher.appendReplacement(sb, "\$1$newResName") // 拼接 保留$1分组,替换$6分组
                } else if (!StringUtils.isEs(ResNewConfiguration.new_prefix)) {
                    newResName = ResNewConfiguration.new_prefix + oldResName
                    matcher.appendReplacement(sb, "\$1$newResName") // 拼接 保留$1分组,替换$6分组
                }

            }
        }
        // 修改了文件时，才写入文件
        if (sb.length() > 0) {
            matcher.appendTail(sb)              // 添加结尾
//            String code = FileTools.GetEncoding(file);
            file.write(sb.toString(), "UTF-8")           // 写回文件
        }
    }
    // ====== 源代码中的部分  end =============================================

    // ====== 资源文件部分公用方法  start =====================
    // def xml_regx = ~/(@XXX\/)(w+)"/      xxx 表示各种资源，如：layout、drawable 等
    /**
     * 操作资源
     * @param file
     * @param set
     * @param regex
     * @param valuesType 是否是 values 类型资源（values-xx, values-en这种）
     *        values 类型资源时，需要保留 $3 分组
     * @return
     */
    def handleResFile(File file, Set<String> set, regex, valuesType = false) {
        boolean hasUpdate = false                 // 是否有修改
        StringBuilder sb = new StringBuilder()    // 文件内容
        file.eachLine("UTF-8") { line ->
            Matcher matcher = line =~ regex
            StringBuffer tSb = new StringBuffer()
            while (matcher.find()) {
                String oldResName = matcher.group(2)
                println("--------------- 旧名字：${oldResName}-------")

                if (set.contains(oldResName)) {
                    String newResName
                    if (!StringUtils.isEs(ResNewConfiguration.old_prefix) && oldResName.contains(ResNewConfiguration.old_prefix)) {
                        newResName = ResNewConfiguration.new_prefix + oldResName.substring(ResNewConfiguration.old_prefix.length())
                        println("--------------- 新名字（2）：${newResName}-------")
                        if (valuesType) {
                            matcher.appendReplacement(tSb, "\$1$newResName\$3")
                            // 拼接 保留$1分组,替换组2,保留组3
                        } else {
                            matcher.appendReplacement(tSb, "\$1$newResName") // 拼接 保留$1分组,替换组2
                        }
                    } else if (!StringUtils.isEs(ResNewConfiguration.new_prefix)) { //前缀 替换
                        newResName = ResNewConfiguration.new_prefix + oldResName
                        println("--------------- 新名字（1）：${newResName}-------")
                        if (valuesType) {
                            matcher.appendReplacement(tSb, "\$1$newResName\$3")
                            // 拼接 保留$1分组,替换组2,保留组3
                        } else {
                            matcher.appendReplacement(tSb, "\$1$newResName") // 拼接 保留$1分组,替换组2
                        }
                    } else if (!StringUtils.isEs(ResNewConfiguration.getInstance().namingScheme) && !oldResName.equals("app_name")) {
                        // 随机命名 替换
                        String str = lookingMatch(oldResName)
                        if (StringUtils.isEs(str)) {
                            str = GetNameAutomatically.getInstance(ResNewConfiguration.getInstance()).getAutomatically()
                            replaceMap.put(oldResName, str)
                        }
                        println("--------------- 新名字：${str}-------")
                        if (valuesType) {
                            matcher.appendReplacement(tSb, "\$1$str\$3")
                            // 拼接 保留$1分组,替换组2,保留组3
                        } else {
                            matcher.appendReplacement(tSb, "\$1$str") // 拼接 保留$1分组,替换组2
                        }
                    }
                }
            }
            if (tSb.length() > 0) {                         // 如果包含了，则重新赋值line，并拼接余下部分
                matcher.appendTail(tSb)
                hasUpdate = true
                line = tSb.toString()
            }

            sb.append(line).append("\r\n")
        }

        // 有修改了，才重新写入文件
        if (hasUpdate) {
            file.write(sb.toString(), "UTF-8")
        }
    }
    // ====== 资源文件部分公用方法  end =====================

    /**
     *  res目录下的资源 - 替换名称
     * @param file
     * @param set
     * @param regx
     * @param dir_filter null no filter
     * @param valuesType 是否是 values 文件夹 类型(如：values，values-en)
     */
    protected def replaceResDir(List<String> fileNameList, Set<String> set, regx, dir_filter, valuesType = false) {
        fileNameList.each { filename ->
            File file = new File(filename)
            File[] dirs = file.listFiles(dir_filter as FilenameFilter)
            dirs?.each { dir ->
                if (dir != null && dir.isDirectory()) {
                    dir.eachFile { it ->
                        if (it.name.endsWith(".xml")) {     // 只在xml有引用
                            handleResFile(it, set, regx, valuesType)
                        }
                    }
                }
            }
        }

        ResNewConfiguration.manifestFilePath.each {
            handleResFile(new File(it), set, regx)
        }
    }
    /**
     * 根据 读取到的 字符串 匹配 要替换的
     * @param line
     * @return
     */
    protected String lookingMatch(String line) {
        String map
        if (line.contains(".")) {
            line = line.substring(0, line.lastIndexOf("."))
        }
        for (Map.Entry<String, String> en : replaceMap.entrySet()) {
            if (line.equals(en.key)) {
                println "replaceMap 中 对应的 数据 -----" + en
                map = en.value
            }
        }
        return map
    }
}

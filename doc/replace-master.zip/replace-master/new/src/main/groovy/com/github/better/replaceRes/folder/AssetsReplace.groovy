package com.github.better.replaceRes.folder

import com.github.better.replaceRes.ResNewConfiguration
import com.github.better.replaceRes.base.BaseFolderResReplace

/**
 * xml
 * @xml / x x x 暂时没有，所以res文件夹先不处理
 */
class AssetsReplace extends BaseFolderResReplace {
    private Set<String> sUFFIXList = new HashSet<String>();

    private def TYPE_NAME = ""

    @Override
    String getResTypeName() {
        return ""
    }

    @Override
    String getJavaRegex() {
        return TYPE_NAME
    }

    @Override
    String getXmlRegex() {
        return TYPE_NAME
    }

    @Override
    Set<String> getResNameSet() {
        Set<String> resNameSet = new HashSet<>()
        ResNewConfiguration.assetsFolderPath.each {filesName ->
            File file = new File(filesName)
            File[] dirs = assetsDir.listFiles()
            dirs?.each { dir ->
                String fileName = dir.name.substring(0, dir.name.lastIndexOf("."))
                resNameSet.add(fileName)
                sUFFIXList.add("\\" + dir.name.replace(fileName, ""))

            }
        }

        println("----------  ----- 文件 后缀..." + sUFFIXList.toString())
        TYPE_NAME = "(\\w+)(" + String.join("|", sUFFIXList) + ")"
        return resNameSet
    }

    @Override
    void replaceSrc(Set<String> resNameSet, Object java_regx) throws IOException {
        println("----------  ----- replace source folder start...")
        replaceSrcDir(ResNewConfiguration.srcFolderPath, resNameSet, java_regx, 0)
        println("----------  ----- replace source folder end")
    }

    @Override
    void replaceRes(Set<String> resNameSet, Object xml_regx) throws IOException {
        // 1.替换文件内容
        println("----------  ----- replace res folder start...")
        replaceResDir(ResNewConfiguration.resFolderPath, resNameSet, xml_regx, null, 0, "")     // only replace xml folder
        println("----------  ----- replace res folder end")
    }


    @Override
    void renameFile(Set<String> resNameSet, Object xml_regx) throws IOException {
        // 2.修改文件名
        println("----------  ----- rename start...")
        renamesFile(ResNewConfiguration.assetsFolderPath, resNameSet, "")
        println("----------  ----- rename end")
    }
}

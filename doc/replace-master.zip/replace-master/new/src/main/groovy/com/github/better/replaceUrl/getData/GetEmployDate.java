package com.github.better.replaceUrl.getData;

import com.github.better.replaceUrl.TestJson;
import com.github.better.replaceUrl.bean.RequestArgsData;
import com.github.better.replaceUrl.bean.UrlDate;
import com.github.better.tools.StringUtils;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;

/**
 * 处理 数据
 * 1.入参 忽略  字段
 * 2.出参 忽略  字段
 */
public class GetEmployDate {
    /**
     * 入参 忽略 字段
     */
    private final static String inParameter = "uuid,token";
    /**
     * 入参 忽略 字段
     */
    private final static String outParameter = "code,message,data";

    public List<UrlDate> getDate(String patch) {
        List<UrlDate> list = new GettingData().getUrlTxt(patch);
        List<String> stringList = TestJson.setNameJson();
        for (int i = 0; i < list.size(); i++) {
            list.get(i).setRequestArgs(disposeInParameter(list.get(i).getRequestArgs()));
            list.get(i).setResponseArgs(disposeOutParameter(list.get(i).getResponseArgs()));
            // 适配 接口 名
            for (int j = 0; j < stringList.size(); j++) {
                if (stringList.get(j).contains(list.get(i).getName()) || list.get(i).getName().contains(stringList.get(j))) {
                    list.get(i).setName(stringList.get(j));
                    break;
                }
            }
        }

        return swapField(list);
    }

    /**
     * 处理 入参 数据
     */
    private List<RequestArgsData> disposeInParameter(List<RequestArgsData> requestArgsData) {
        List<RequestArgsData> list = new ArrayList<>();
        for (int i = 0; i < requestArgsData.size(); i++) {
//            System.out.println("入参 ------" + requestArgsData.get(i).getName());
            String string = removeExpandSentence1(requestArgsData.get(i).getName());
            if (!StringUtils.isEs(string)) {
                if (inParameter.contains(string)) {
                    list.add(requestArgsData.get(i));
                }
                if (string.contains("(") && string.contains(")")) {
                    requestArgsData.get(i).setName(extractExpandSentence(string));

                } else if (string.contains("-")) {
                    String[] strdd = string.split("-");
                    if (null != strdd && strdd.length == 2) {
                        requestArgsData.get(i).setName(removeExpandSentence2(string));
                    }
                }
            }
        }
//        System.out.println("入参处理  要删除的  ------" + list.toString());

        for (int i = 0; i < list.size(); i++) {
            requestArgsData.remove(list.get(i));
        }
//        System.out.println("入参处理后 ------" + requestArgsData.toString());
        return requestArgsData;
    }

    /**
     * 处理 出参 数据
     */
    private List<RequestArgsData> disposeOutParameter(List<RequestArgsData> responseArgs) {
        List<RequestArgsData> list = new ArrayList<>();
        List<RequestArgsData> datalist = new ArrayList<>();

        for (int i = 0; i < responseArgs.size(); i++) {
            String string = removeExpandSentence1(responseArgs.get(i).getName());

            if (!StringUtils.isEs(string) && outParameter.contains(string)) {
                list.addAll(responseArgs.get(i).getChildren());
                datalist.add(responseArgs.get(i));
            }
        }

        for (int i = 0; i < datalist.size(); i++) {
            responseArgs.remove(datalist.get(i));
        }
        if (list.size() > 0) {
            responseArgs.addAll(list);
        }


        for (int i = 0; i < responseArgs.size(); i++) {
//            System.out.println("出参 ------" + responseArgs.get(i).getName());
            String string = removeExpandSentence1(responseArgs.get(i).getName());
            if (!StringUtils.isEs(string)) {
                if (string.contains("(") && string.contains(")")) {
                    responseArgs.get(i).setName(extractExpandSentence(string));
                } else if (string.contains("-")) {
                    String[] strdd = string.split("-");
                    if (null != strdd && strdd.length == 2) {
                        responseArgs.get(i).setName(removeExpandSentence2(string));
                    }
                }
            }
            List<RequestArgsData> childrenList = responseArgs.get(i).getChildren();
            if (null != childrenList && childrenList.size() > 0) {
                for (int j = 0; j < childrenList.size(); j++) {
                    String string1 = removeExpandSentence1(childrenList.get(j).getName());
                    if (string1.contains("(") && string1.contains(")")) {
                        childrenList.get(j).setName(extractExpandSentence(string1));
                    } else if (string1.contains("-")) {
                        String[] strdd = string1.split("-");
                        if (null != strdd && strdd.length == 2) {
                            childrenList.get(j).setName(removeExpandSentence2(string1));
                        }
                    }

                    List<RequestArgsData> childrenList1 = childrenList.get(j).getChildren();
                    if (null != childrenList1 && childrenList1.size() > 0) {
                        for (int c = 0; c < childrenList1.size(); c++) {
                            String string2 = removeExpandSentence1(childrenList1.get(c).getName());
                            if (string2.contains("(") && string2.contains(")")) {
                                childrenList1.get(c).setName(extractExpandSentence(string2));
                            } else if (string2.contains("-")) {
                                String[] strdd = string2.split("-");
                                if (null != strdd && strdd.length == 2) {
                                    childrenList1.get(c).setName(removeExpandSentence2(string2));
                                }
                            }


                        }
                        childrenList.get(j).setChildren(childrenList1);
                    }

                }
                responseArgs.get(i).setChildren(childrenList);
            }
        }
//        System.out.println("出参处理  要删除的  ------" + list.toString());

//        System.out.println("出参处理后 ------" + responseArgs.toString());
        return responseArgs;
    }

    /**
     * 对调
     *
     * @return
     */
    private List<UrlDate> swapField(List<UrlDate> list) {
        AbstractMap.SimpleEntry<String, String> mapEntry = TestJson.getCorrespondence();
        List<RequestArgsData> requestArgsDataList = new ArrayList<RequestArgsData>();
        for (int i = 0; i < list.size(); i++) {
            if (mapEntry.getKey().contains(list.get(i).getName())) {
                requestArgsDataList.addAll(list.get(i).getRequestArgs());
            }
        }
        System.out.println("对调 字段 " + requestArgsDataList.toString());
        for (int i = 0; i < list.size(); i++) {
            System.out.println("对调 字段 " + list.get(i).getName());

            if (mapEntry.getValue().equals(list.get(i).getName())) {
                System.out.println("");
                list.get(i).setResponseArgs(requestArgsDataList);
                break;
            }
        }
        System.out.println("对调 后 数据 " + list.toString());
        return list;
    }

    /**
     * 去除 “（ ）”
     */
    public static String removeExpandSentence2(String str) {
        if (StringUtils.isEs(str)) {
            return str;
        }
        return str.replace("-", ",").trim();
    }

    /**
     * 提取 （） 中 字段名
     * <p>
     * 改 , 分割
     *
     * @param str
     * @return
     */
    public static String extractExpandSentence(String str) {
        if (StringUtils.isEs(str)) {
            return str;
        }
        return str.replace("(", ",").replace(")", "").trim();
    }

    /**
     * 去除 特殊 字符
     *
     * @param str
     * @return
     */
    public static String removeExpandSentence1(String str) {
        if (StringUtils.isEs(str)) {
            return str;
        }
        if (str.contains("（")) {
            str = str.replaceAll("（", "(");
        }
        if (str.contains("）")) {
            str = str.replace("）", ")");
        }
        return str;
    }


}

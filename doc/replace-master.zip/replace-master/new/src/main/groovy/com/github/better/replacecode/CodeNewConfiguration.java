package com.github.better.replacecode;

import com.github.better.NewConfiguration;

import java.util.List;
import java.util.Map;

/**
 * 代码 修改
 */
public class CodeNewConfiguration extends NewConfiguration {
    /**
     * 新的资源前缀   ---  旧前缀（后缀）
     */
    public static Map<String, String> prefixs ;

    /**
     * 清单文件路径
     */
    public static List<String> manifestFilePath;


    /**
     * 需要处理的文件
     */
    public static List<String> ReviseFilePath;

    /**
     * 需要处理的class文件
     *
     *
     */
    public static List<String> CalssFilePath;

    private static CodeNewConfiguration INSTANCE = null;

    public static CodeNewConfiguration getInstance() {
        if (INSTANCE != null) {
            return INSTANCE;
        }

        INSTANCE = new CodeNewConfiguration();
        return INSTANCE;
    }


    public static void init(Map<String, String> new_prefixs, List<String> srcFolderPaths,List<String> resFolderPaths, List<String> manifestFilePaths, List<String> ReviseFilePaths, List<String> CalssFilePaths) {
        prefixs = new_prefixs;
        resFolderPath = resFolderPaths;
        srcFolderPath = srcFolderPaths;
        manifestFilePath = manifestFilePaths;
        ReviseFilePath = ReviseFilePaths;
        CalssFilePath = CalssFilePaths;
    }

}

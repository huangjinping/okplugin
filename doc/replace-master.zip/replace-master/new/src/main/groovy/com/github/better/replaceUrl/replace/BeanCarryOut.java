package com.github.better.replaceUrl.replace;

import com.github.better.replaceUrl.UrlNewConfiguration;
import com.github.better.replaceUrl.base.BaseUrlReplace;
import com.github.better.replaceUrl.bean.RequestArgsData;
import com.github.better.tools.FileTools;
import com.github.better.tools.StringUtils;

import java.util.Iterator;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyObject;

/**
 * 出参 替换
 */
public class BeanCarryOut extends BaseUrlReplace {


    private Map<String, String> field = new HashMap<>();


    RequestArgsData replaceUrlDate = null;
    int index_i = -1;
    int index_j = -1;

    Map<String, List<RequestArgsData>> secondLevel = new HashMap();

    @Override
    public String replaceStr(String str) {
        String str1 = str.replaceAll("\\*", "").trim();
        if (StringUtils.isEs(str1) || "/".equals(str1) || "//".equals(str1)) {
            return str;
        }
        System.out.println("读取 到的 字符串 ----" + str1);
        if (str1.contains("//")) {
            str1 = str1.substring(str1.lastIndexOf("//") + "//".length());
        }

        float similarity_i = 0;

        if (null == replaceUrlDate) {
            System.out.println(" ---replaceUrlDate------ 在的位置---------------------" + atPresent.toString());
            for (int i = 0; i < atPresent.size(); i++) {
                RequestArgsData requestArgsData = atPresent.get(i);
                float similarityd = 0;
//                float similarityd1 = 0;
//                float similarityd2 = 0;
//                if (atPresent.get(i).getName().contains(",") && str.contains("private") && str.contains(";")) {
//                    String str10 = StringUtils.stringMatch2(str, atPresent.get(i).getName());
//                    if (!StringUtils.isEs(str10)) {
////                        atPresent.get(i).setName(str10);
////                        requestArgsData.setName(str10);
//                        similarityd1 = 1;
//                    }
//                }
                similarityd = StringUtils.levenshtein(requestArgsData.getDescription(), str1) + StringUtils.stringMatch2(str, atPresent.get(i).getName());
                if (similarityd == 2) {
                    index_i = i;
                    break;
                } else if (similarityd >= 0.9 && similarityd >= similarity_i) {
                    index_i = i;
                    similarity_i = similarityd;
                }
                if (null != requestArgsData.getChildren() && requestArgsData.getChildren().size() > 0) {
                    List<RequestArgsData> l1 = requestArgsData.getChildren();
                    System.out.println(" ---replaceUrlDate------ 二级目录---------------------" + l1.toString());

                    for (int j = 0; j < l1.size(); j++) {
                        similarityd = 0;

//                        if (similarityd == 0) {
//                            similarityd2 = StringUtils.levenshtein(l1.get(j).getDescription(), str1.trim());
//                        }

                        similarityd = StringUtils.levenshtein(l1.get(j).getDescription(), str1.trim()) + StringUtils.stringMatch2(str, l1.get(j).getName());

                        if (similarityd == 1) {
                            index_j = j;
                            index_i = i;
                            break;
                        } else if (similarityd >= 0.9 && similarityd >= similarity_i) {
                            index_i = i;
                            index_j = j;
                            similarity_i = similarityd;
                        }
                    }
                }
            }
            System.out.println(" ---修改 bean------ 在的位置---------------------//" + (index_i) + "----apiUrl中的---//" + (index_j));

            if (index_i != -1 && index_j != -1) {
                System.out.println("基准 ------------------------------" + atPresent.get(index_i).getChildren().get(index_j).getName() + "----apiUrl中的---" + str);
                replaceUrlDate = atPresent.get(index_i).getChildren().get(index_j);
                if (replaceUrlDate.getName().contains(",") && str.contains("private") && str.contains(";")) {
                    String str10 = StringUtils.stringMatch(str, replaceUrlDate.getName());
                    if (!StringUtils.isEs(str10)) {
                        replaceUrlDate.setName(str10);
                    }
                }
                atPresent.get(index_i).getChildren().remove(index_j);
            } else if (index_i != -1) {
                System.out.println("基准 ------------------------------" + atPresent.toString() + "----apiUrl中的---" + str);

                System.out.println("基准 ------------------------------" + atPresent.get(index_i).getName() + "----apiUrl中的---" + str);
                replaceUrlDate = atPresent.get(index_i);
                if (replaceUrlDate.getName().contains(",") && str.contains("private") && str.contains(";")) {
                    String str10 = StringUtils.stringMatch(str, replaceUrlDate.getName());
                    if (!StringUtils.isEs(str10)) {
                        replaceUrlDate.setName(str10);
                    }
                }
                if (null == replaceUrlDate.getChildren() || replaceUrlDate.getChildren().size() == 0) {
                    System.out.println("删除 ------------------------------" + replaceUrlDate.toString());

                    atPresent.remove(index_i);
                }
            }
        }
        String standardString = "private ";
        System.out.println("到这的数据 ----" + str);
        if (str.contains(standardString)) {
//            if (null == replaceUrlDate && null != atPresent && atPresent.size() == 1) {
//                replaceUrlDate = atPresent.get(0);
//            } else
            if (null != replaceUrlDate) {

                System.out.println("替换的url --------------" + replaceUrlDate.toString() + "----------------" + replaceUrlDate.getName() + "-------");
//                String s1 = StringUtils.getStringFrom(" ", ";", str.trim());

                String[] sd = StringUtils.stringSegmentation(str);
                System.out.println("数据 分段 ----" + sd);
                if (sd.length >= 3) {
                    String s1 = sd[2];
                    System.out.println("旧的 字段名 ----" + s1);
                    if (sd[2].contains(";")) {
                        s1 = sd[2].substring(0, sd[2].indexOf(";"));
                    }
                    if (!"String".equals(sd[1].trim()) && !"boolean".equals(sd[1].trim())) {
                        String str3 = sd[1].trim();
                        if (str3.contains("ArrayList<")) {
                            String str4 = StringUtils.getStringFrom("ArrayList<", ">", str3);
                            if (!getFileName(str4) && !StringUtils.isBasicType(str4) && !StringUtils.isEs(str4)) {
                                secondLevel.put(str4, replaceUrlDate.getChildren());
                                str = str.replace(str4, getString2(str4, StringUtils.stringMatch1(s1, replaceUrlDate.getName())));
                            }
                        } else if (str3.contains("List<")) {
                            String str4 = StringUtils.getStringFrom("List<", ">", str3);
                            if (!getFileName(str4) && !StringUtils.isBasicType(str4) && !StringUtils.isEs(str4)) {
                                secondLevel.put(str4, replaceUrlDate.getChildren());
                                str = str.replace(str4, getString2(str4, StringUtils.stringMatch1(s1, replaceUrlDate.getName())));
                            }
                        } else {
                            if (!getFileName(str3) && !StringUtils.isBasicType(str3) && !StringUtils.isEs(str3)) {
                                secondLevel.put(str3, replaceUrlDate.getChildren());
                                str = str.replace(str3, getString2(str3,StringUtils.stringMatch1(s1, replaceUrlDate.getName())));
                            }
                        }
                    }


                    String s = StringUtils.stringMatch1(s1, replaceUrlDate.getName());
                    if (!StringUtils.isEs(s)) {
                        field.put(s1.trim(), s);
                        str = str.replace(s1.trim(), s);
                    }
                }
                System.out.println("bean 字段 结尾时 Str -------" + str);
                if (str.contains(";")) {
                    replaceUrlDate = null;
                    index_i = -1;
                    index_j = -1;
                }
            }

        } else if (str.trim().startsWith("return")) {
            String str2 = str.substring(str.indexOf("return") + "return".length(), str.indexOf(";")).trim();
            System.out.println("return 处理完数据 ------" + str2);
            Set<String> strings = field.keySet();
            for (String s : strings) {
                if (str2.equals(s)) {
                    str = str.replaceAll(s, field.get(s));
                    break;
                }
            }
        } else if (str.contains(".writeString(")) {
            Set<String> strings = field.keySet();
            String str2 = "";
            if (str1.contains("this.")) {
                str2 = str1.substring(str1.indexOf("this.") + "this.".length(), str1.indexOf(");")).trim();
            } else {
                str2 = str1.substring(str1.indexOf("(") + "(".length(), str1.indexOf(");")).trim();
            }
            // System.out.println(".writeString( 处理完数据 ------" + str2);
            if (!StringUtils.isEs(str2)) {
                for (String s : strings) {
                    if (str2.equals(s)) {
                        str = str.replaceAll(s, field.get(s));
                        break;
                    }
                }
            }
        } else if (str.contains("this.")) {
            Set<String> strings = field.keySet();
            String str2 = str.substring(str.indexOf("this.") + "this.".length(), str.indexOf("=")).trim();
            System.out.println("this. 处理完 数据------" + str2);
            for (String s : strings) {
                if (str2.equals(s)) {
                    str = str.replaceAll(s, field.get(s));
                    break;
                }
            }
        } else if (str.contains("(")) {
            System.out.println("要 替换的 字符串 -------------------" + str.trim());
            Set<String> strings = field.keySet();
            System.out.println("替换字符串  的数据-------------------" + strings.toString());

            for (String s : strings) {
                if (str1.contains(StringUtils.toUpperCaseStr(s) + "(")) {
                    str = str.replaceAll(StringUtils.toUpperCaseStr(s), StringUtils.toUpperCaseStr(field.get(s)));
                } else if (str1.contains(StringUtils.toUpperCaseStr(s.replace("is", "")) + "(")) {
                    str = str.replaceAll(StringUtils.toUpperCaseStr(s), StringUtils.toUpperCaseStr(field.get(s).replace("is", "")));
                } else if (str1.contains(s)) {
                    str = str.replaceAll(s, field.get(s));
                }
                if (str.contains("(") && str.contains("(") && str.contains("public")) {
                    String str2 = StringUtils.getStringFrom("(", ")", str.trim());
                    if (!StringUtils.isEs(str2) && str2.split(" ").length == 2 && StringUtils.check(str2)) {
                        if (str2.split(" ")[1].trim().equals(s)) {
                            str = str.replaceAll(str2.split(" ")[1], field.get(s));
                        }
                    }
                }
            }
        } else if (str.contains("public static class")) {
            if (secondLevel.size() > 0) {
                Set<String> stringSet = secondLevel.keySet();
                for (String s : stringSet) {
                    if (str.contains(s)) {
                        secondLevel.remove(s);
                        break;
                    }
                }
            }
        }
        return str;
    }

    private boolean getFileName(String fileName) {
        Set<String> s = mBeadNameList.keySet();
        for (String value : s) {
            if (value.equals(fileName)) {
                return true;
            }
        }
        return false;
    }

    private List<RequestArgsData> atPresent;

    Map<String, String> replaceField = new HashMap<>();

    /**
     * bean类 字段名  数据
     */
    Map<String, List<RequestArgsData>> mBeadNameList;

    /**
     * 数据类 名  对应的  旧名字 --- 新名字
     */
    Map<String, String> beanNameList;

    /**
     * 在数据类中 查找
     *
     * @param line
     * @return
     */
    private Map.Entry<String, String> getString3(String line) {
        if (StringUtils.isEs(line)) {
            return null;
        }
        for (Map.Entry<String, String> en : beanNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.trim().equals(en.getKey().trim())) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en;
            }
        }
        return null;
    }

    private String getString2(String oldName, String jsonName) {
        //是否有 一个接口  两个调用方法的问题
        Map.Entry<String, String> entry = getString3(oldName);
        String newName = null;

        if (null != entry) {
            newName = entry.getValue();
        } else {
            newName = substitutionMethodName1(UrlNewConfiguration.apiUrlBeanName, jsonName);
            if (beanNameList.containsValue(newName)) {
                newName = substitutionMethodName1(UrlNewConfiguration.apiUrlBeanName, jsonName + getMultiLetter(3));
            }
            beanNameList.put(oldName, newName.trim());
        }
        System.out.println("要修改的 数据 ---------" + oldName+"-------"+jsonName);
        return newName;
    }

    /**
     * 获取 多个字母
     *
     * @param size
     * @return
     */
    public String getMultiLetter(int size) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < size; i++) {
            sb.append((char) (int) (Math.random() * 26 + 97));
        }
        return sb.toString();
    }

    /**
     *
     * @param mBeadNameList  bean 字段名  数据
     * @param beanNameList   apiurl 数据类 名
     */
    public void replaceBean(Map<String, List<RequestArgsData>> mBeadNameList, Map<String, String> beanNameList) {
        this.mBeadNameList = mBeadNameList;
        this.beanNameList = beanNameList;
        ArrayList<String> listFileName = new ArrayList<>();
        for (String fileName : UrlNewConfiguration.srcFolderPath) {
            FileTools.getFileName(fileName, listFileName);
        }
        Set<String> s = mBeadNameList.keySet();
        List<String> list = new ArrayList<>();
        for (int i = 0; i < listFileName.size(); i++) {
            for (String value : s) {
                if (listFileName.get(i).contains(value)) {
                    atPresent = mBeadNameList.get(value);
                    replaceUrlDate = null;
                    System.out.println("要修改的 数据 ---------" + atPresent.toString());
                    System.out.println("要修改的 bean 文件 ---------" + listFileName.get(i));
                    replaceSrcDir(new File(listFileName.get(i)));
                    if (field.size() > 0) {
                        replaceField.putAll(field);
                    }
                    field.clear();
                    list.add(listFileName.get(i));
                }
            }
        }
        for (int j = 0; j < 4; j++) {
            if (secondLevel.size() > 0) {
                for (int i = 0; i < listFileName.size(); i++) {
                    Set<String> s1 = secondLevel.keySet();
//                    System.out.println("二级 bean 类  s1 -----------------------" + s1.toString());
                    for (Iterator<String> it = s1.iterator(); it.hasNext(); ) {
                        String value = it.next();
                        if (listFileName.get(i).contains(value)) {
                            atPresent = secondLevel.get(value);
                            replaceUrlDate = null;
                            System.out.println("要修改的 数据 ---------" + atPresent.toString());
                            System.out.println("要修改的 bean 文件 ---------" + listFileName.get(i));
                            replaceSrcDir(new File(listFileName.get(i)));
                            if (field.size() > 0) {
                                replaceField.putAll(field);
                            }
                            field.clear();
                            list.add(listFileName.get(i));
                            secondLevel.remove(value);
                            break;
                        }
                    }
                }
            } else {
                break;
            }
        }


        // 去除已处理的 文件
        for (int i = 0; i < list.size(); i++) {
            listFileName.remove(list.get(i));
        }

        //替换 调用网络接口返回 数据类名
        if (null != beanNameList && beanNameList.size() > 0) {
            try {
                Class clazz;
                try (GroovyClassLoader loader = new GroovyClassLoader()) {
                    clazz = loader.loadClass("com.github.better.replaceUrl.replace.BeanNameReplace");
                }
                // 获得GroovyShell_2的实例
                GroovyObject groovyObject = (GroovyObject) clazz.newInstance();
                // 反射调用sayHello方法得到返回值
                groovyObject.invokeMethod("replaceCode", new Object[]{beanNameList, listFileName});

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        new CodeToReplace().replaceCode(replaceField, listFileName);
    }
}


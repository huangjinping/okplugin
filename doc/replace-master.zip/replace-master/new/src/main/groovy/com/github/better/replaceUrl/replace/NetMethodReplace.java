package com.github.better.replaceUrl.replace;

import com.github.better.replaceUrl.UrlNewConfiguration;
import com.github.better.replaceUrl.base.BaseUrlReplace;
import com.github.better.tools.FileTools;
import com.github.better.tools.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
/**
 * 代码 替换  替换
 * 替换 调用网络接口的方法
 */
public class NetMethodReplace extends BaseUrlReplace {

    /**
     * 存储 调用网络接口  旧方法 ---> 新方法名
     */
    private Map<String, String> mBeadNameList;
    /**
     * 存储 调用mvp 接口  旧方法 ---> 新方法名
     */
    private Map<String, String> mBeadNameList2 = new HashMap<String, String>();
    private Set<String> stringSet;

    /**
     * 新的接口方法名
     */
    String strq = null;

    private boolean ds = false;


    private String str2 = null;

    /**
     * 读取到的 每一行 的回调
     *
     * @param str 一行 代码
     * @return
     */
    @Override
    public String replaceStr(String str) {
        String str1 = str.replace("*", "").trim();
        if (StringUtils.isEs(str1)) {
            return str;
        }
//        System.out.println("读取到的一行 NetMethodReplace ----" + str);

        if (str.contains("(") && !StringUtils.isEs(strq) && getString3(str1)) { //是否是 调取 接口的 一行
            String mBeanMame = StringUtils.getStringFrom2(UrlNewConfiguration.viewMethodName + ".", "(", str);
            if (StringUtils.isEs(mBeanMame)) {
                return str;
            }
            Map.Entry<String, String> entry = getString1(mBeanMame);
            String newName = null;
            if (null != entry) {
                if (!ds) {  //成功方法
                    ds = true;
                } else { //失败方法
                    ds = false;
                    strq = null;
                }
                str = str.replace(mBeanMame, entry.getValue());
            } else {
                if (!ds) {  //成功方法
                    ds = true;
                    newName = substitutionMethodName(UrlNewConfiguration.urlResultMethodName, strq);
                } else { //失败方法
                    ds = false;
                    newName = substitutionMethodName(UrlNewConfiguration.urlErrorResultMethodName, strq);
                    strq = null;
                }
//                System.out.println("成功 失败 方法 NetMethodReplace ----" + mBeanMame + "------" + newName);
                str = str.replace(mBeanMame, newName);
                mBeadNameList2.put(mBeanMame.trim(), newName.trim());
            }
        } else if (str.contains(".") && str.contains("(") && !str.contains(";")) { //是否是 调取 api 方法的 一行
//            System.out.println("调取 api 方法 NetMethodReplace ----" + str);
            Map.Entry<String, String> entry = getString(str);
            if (null != entry) {
//                System.out.println("调取 api  方法 NetMethodReplace ----" + entry.getKey() + "---------" + substitutionMethodName(UrlNewConfiguration.apiUrlMethodName, entry.getValue()));
                str = str.replace(entry.getKey(), substitutionMethodName(UrlNewConfiguration.apiUrlMethodName, entry.getValue()));
//                System.out.println("调取 api 成功 替换 后 ----" + str);
                strq = entry.getValue();
                //调取 mvp接口 方法名  替换 新 名称  保存  到  map 中
                getString2(entry.getKey(), entry.getValue());
            }
        } else if (str.contains("public void ") && str.contains("(")) {
            str2 = StringUtils.getStringFrom2("public void ", "(", str);
//            System.out.println("调取 接口 方法名 ----" + str2);
        }
        return str;
    }

    public void replaceCode(Map<String, String> mBeadNameList, ArrayList<String> listFileName) {
        this.mBeadNameList = mBeadNameList;
        this.stringSet = mBeadNameList.keySet();

        mBeadNameList2 = new HashMap<String, String>();
        listFileName.clear();
        for (String str : UrlNewConfiguration.srcFolderPath){
            FileTools.getFileName(str, listFileName);
        }
        for (int i = 0; i < listFileName.size(); i++) {
            replaceSrcDir(new File(listFileName.get(i)));
        }
        //替换 调用mvp 接口的方法
        if (null != mBeadNameList2 && mBeadNameList2.size() > 0) {
            new MethodReplace().replaceCode(mBeadNameList2, listFileName);
        }
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     *
     * @param line
     * @return
     */
    private Map.Entry<String, String> getString(String line) {
        if (StringUtils.isEs(line)) {
            return null;
        }
        for (Map.Entry<String, String> en : mBeadNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.contains("." + en.getKey().trim() + "(")) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en;
            }
        }
        return null;
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     *
     * @param line
     * @return
     */
    private boolean getString3(String line) {
        line = line.trim();
        if (StringUtils.isEs(line)) {
            return false;
        }

        String str1 = UrlNewConfiguration.viewMethodName + ".";
        if (line.length() > str1.length()) {
            if (str1.equals(line.substring(0, str1.length()))) {
                return true;
            }
        }
        return false;
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     *
     * @param line
     * @return
     */
    private void getString2(String line, String line2) {
        if (StringUtils.isEs(line)) {
            return;
        }
        boolean flag = true;
        for (Map.Entry<String, String> en : mBeadNameList2.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.equals(en.getKey().trim())) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                flag = false;
                break;
            }
        }
        if (flag) {
            mBeadNameList2.put(str2.trim(), substitutionMethodName(UrlNewConfiguration.urlPgetMethodName, line2).trim());
            str2 = null;
        }
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     *
     * @param line
     * @return
     */
    private Map.Entry<String, String> getString1(String line) {
        if (StringUtils.isEs(line)) {
            return null;
        }
        for (Map.Entry<String, String> en : mBeadNameList2.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.trim().equals(en.getKey().trim())) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        String str1 = "void fanhuiyinghangkaliebiao(BaseResponseBean<List<LiebiaoBankBean>> responseBean);";
        String str2 = "fanhuiyinghangkaliebiao(";
        if (str1.contains(str2)) {
//                println() "replaceMap 中 对应的 数据 -----" + en
            int l = str1.indexOf(str2);
            System.out.println("可以" + l);
            if (str1.length() - 1 > l) {
                String str3 = str1.substring(l - 1, l);
                System.out.println("可以" + str3 + "-----");
                if (StringUtils.isEs(str3)) {
                    System.out.println("可以");
                }
            } else if (str1.length() - 1 == l) {
                System.out.println("可以");
            }
        }


    }

}



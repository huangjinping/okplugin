package com.github.better

import com.github.better.replaceId.IdReplacePlugin
import com.github.better.replaceUrl.UrlReplacePlugin
import com.github.better.replaceRes.ResReplacePlugin
import com.github.better.replacecode.CodeReplacePlugin
import org.gradle.api.Plugin
import org.gradle.api.Project

/**
 * 入口
 */
class ReplaceToolsPlugin implements Plugin<Project> {

    static final String APP = "com.android.application"
    static final String LIBRARY = "com.android.library"

    @Override
    void apply(Project project) {
        if (!(project.plugins.hasPlugin(APP) || project.plugins.hasPlugin(LIBRARY))) {
            throw new IllegalArgumentException(
                    'replaceRes gradle plugin can only be applied to android projects.')
        }

        // === Create replaceResName Task
        //替换 资源 名称
        new ResReplacePlugin().startPlugin(project)
        // 替换 接口 相关 数据
        new UrlReplacePlugin().startPlugin(project)
        //替换 布局 id 相关数据
        new IdReplacePlugin().startPlugin(project)
        //替换 代码 命名修改 相关数据
        new CodeReplacePlugin().startPlugin(project)
    }
}
package com.github.better.replaceUrl.bean;


import com.alibaba.fastjson2.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

public class EnvironmentsData {

    @JSONField(name = "name")
    private String name;
    @JSONField(name = "t")
    private Long t;
    @JSONField(name = "vars")
    private List<VarsDTO> vars;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getT() {
        return t;
    }

    public void setT(Long t) {
        this.t = t;
    }

    public List<VarsDTO> getVars() {
        return vars;
    }

    public void setVars(List<VarsDTO> vars) {
        this.vars = vars;
    }

    @Override
    public String toString() {
        return "EnvironmentsData{" +
                "name='" + name + '\'' +
                ", t=" + t +
                ", vars=" + vars +
                '}';
    }

    public static class VarsDTO implements Serializable {
        @JSONField(name = "value")
        private String value;
        @JSONField(name = "name")
        private String name;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return "VarsDTO{" +
                    "value='" + value + '\'' +
                    ", name='" + name + '\'' +
                    '}';
        }
    }
}

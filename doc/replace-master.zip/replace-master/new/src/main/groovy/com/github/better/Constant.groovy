package com.github.better
/**
 * anim
 */
class Constant  {
    /**
     *  R.Layout 匹配 正则
     */
    public  final static  String  JAVA_REGEX = "(R(\\s*?)\\.(\\s*?)layout(\\s*?)\\.(\\s*?))(\\w+)"

    /**
     *  R.drawable 匹配 正则
     */
    public  final static  String   DRAWABLE_REGEX = "(R(\\s*?)\\.(\\s*?)drawable(\\s*?)\\.(\\s*?))(\\w+)"

    /**
     *  R.anim 匹配 正则
     */
    public  final static  String  ANIM_REGEX = "(R(\\s*?)\\.(\\s*?)anim(\\s*?)\\.(\\s*?))(\\w+)"
    /**
     *  R.String 匹配 正则
     */
    public  final static  String  STRING_REGEX = "(R(\\s*?)\\.(\\s*?)string(\\s*?)\\.(\\s*?))(\\w+)"

    /**
     *  R.id 匹配 正则
     */
    public  final static  String  ID_REGEX = "(R(\\s*?)\\.(\\s*?)id(\\s*?)\\.(\\s*?))(\\w+)"
    /**
     *  R.color 匹配 正则
     */
    public  final static  String  COLOR_REGEX = "(R(\\s*?)\\.(\\s*?)color(\\s*?)\\.(\\s*?))(\\w+)"

    /**
     *  @+id 匹配 正则
     */
    public  final static  String  Id_REGEdsdX = "(@(\\s*?)\\+(\\s*?)id(\\s*?)\\/(\\s*?))(\\w+)"

    /**
     * @color 匹配 正则
     */
    public  final static  String  COLOR_REGEdsdX = "(@(\\s*?)color(\\s*?)\\/(\\s*?))(\\w+)"

    /**
     * @drawable 匹配 正则
     */
    public  final static  String DRAWABLE_REGEdsdX = "(@(\\s*?)drawable(\\s*?)\\/(\\s*?))(\\w+)"
    /**
     * @Layout 匹配 正则
     */
    public  final static  String LAYOUT_REGEdsdX = "(@(\\s*?)Layout(\\s*?)\\/(\\s*?))(\\w+)"
    /**
     * @String 匹配 正则
     */
    public  final static  String STRING_REGEdsdX = "(@(\\s*?)String(\\s*?)\\/(\\s*?))(\\w+)"

}

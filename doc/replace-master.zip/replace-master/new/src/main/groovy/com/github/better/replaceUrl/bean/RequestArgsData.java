package com.github.better.replaceUrl.bean;

import com.alibaba.fastjson2.annotation.JSONField;

import java.util.List;

public class RequestArgsData {

    @JSONField(name = "type")
    private String type;
    @JSONField(name = "require")
    private String require;
    @JSONField(name = "name")
    private String name;
    @JSONField(name = "description")
    private String description;
    @JSONField(name = "children")
    private List<RequestArgsData> children;
    @JSONField(name = "testValue")
    private String testValue;


    private boolean isReplace = false;

    public boolean isReplace() {
        return isReplace;
    }

    public void setReplace(boolean replace) {
        isReplace = replace;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRequire() {
        return require;
    }

    public void setRequire(String require) {
        this.require = require;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<RequestArgsData> getChildren() {
        return children;
    }

    public void setChildren(List<RequestArgsData> children) {
        this.children = children;
    }

    public String getTestValue() {
        return testValue;
    }

    public void setTestValue(String testValue) {
        this.testValue = testValue;
    }

    @Override
    public String toString() {
        return "RequestArgsData{" +
                "type='" + type + '\'' +
                ", require='" + require + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", children=" + children +
                ", testValue='" + testValue + '\'' +
                ", isReplace=" + isReplace +
                '}';
    }
}

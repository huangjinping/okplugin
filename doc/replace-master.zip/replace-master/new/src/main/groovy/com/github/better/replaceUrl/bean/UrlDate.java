package com.github.better.replaceUrl.bean;

import java.util.List;

public class UrlDate {
    private List<RequestArgsData> requestArgs;

    private List<RequestArgsData> responseArgs;

    private String url;

    private String name;

    public List<RequestArgsData> getRequestArgs() {
        return requestArgs;
    }

    public void setRequestArgs(List<RequestArgsData> requestArgs) {
        this.requestArgs = requestArgs;
    }

    public List<RequestArgsData> getResponseArgs() {
        return responseArgs;
    }

    public void setResponseArgs(List<RequestArgsData> responseArgs) {
        this.responseArgs = responseArgs;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    @Override
    public String toString() {
        return "UrlDate{" +
                "requestArgs=" + requestArgs +
                ", responseArgs=" + responseArgs +
                ", url='" + url + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}

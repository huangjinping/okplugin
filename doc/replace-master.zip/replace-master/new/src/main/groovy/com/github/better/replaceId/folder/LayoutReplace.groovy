package com.github.better.replaceId.folder

import com.github.better.Constant
import com.github.better.NewConfiguration
import com.github.better.replaceRes.Tools
import com.github.better.tools.FileTools
import com.github.better.tools.GetNameAutomatically
import com.github.better.tools.StringUtils

import java.util.regex.Matcher

/**
 * layout 布局资源
 */
public class LayoutReplace {

    private def final DIR_FILTER = new Tools.DirNamePrefixFilter("layout")
//    private def final RES_TYPE_NAME = "layout"
    GetNameAutomatically getNameAutomatically


    LayoutReplace() {
        getNameAutomatically = GetNameAutomatically.getInstance(NewConfiguration.getInstance())
    }

//    String getResTypeName() {
//        return RES_TYPE_NAME
//    }


//    String getJavaRegex() {
//        // group 6 为名字
//        return "(R(\\s*?)\\.(\\s*?)id(\\s*?)\\.(\\s*?))(\\w+)"
//    }


    String getXmlRegex() {
        // group 2为名字
        return "(@id/|@\\+id/)(\\w+)"
    }

    Map<String, String> replaceMap = new HashMap<>()

    Set<String> getResNameSet() {
        Set<String> layoutNameSet = new HashSet<>()

        NewConfiguration.resFolderPath.each {
            // 1.获取所有layout开头的文件夹
            File[] layoutDirs = new File(it).listFiles(DIR_FILTER)
            // 2.获取layout名字并存储
            layoutDirs?.each { layoutDir ->
                layoutDir.eachFile { idt ->
                    layoutNameSet.add(idt.getPath())
                }
            }
        }
        println "获取到的 layout 文件 ${layoutNameSet.toString()}"
        return layoutNameSet
    }
    /**
     * 模板方法
     * @throws IOException
     */
    final void replaceThis() throws IOException {
        Set<String> resNameSet = getResNameSet()
        replaceMap.clear()
        handleResFile(resNameSet, getXmlRegex())

        NewConfiguration.srcFolderPath.each {
            replaceSrcDir(new File(it))
        }

    }

    /**
     * 替换 src 源代码目录中的资源名
     * @param file 源代码目录
     * @param set 当前module下所有资源名 set
     * @param java_regx 匹配正则
     */
    private void replaceSrcDir(File file) {
        if (file.exists()) {
            if (file.isDirectory()) {
                file.eachFile { it -> replaceSrcDir(it) }
            } else {
                if (file.name.endsWith(".java") || file.name.endsWith(".kt")) {
                    // only .java or .kt files
                    handleSrcFile(file)
                }
            }
        }
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     * @param line
     * @return
     */
    private List<Map.Entry<String, String>> getString(String line) {
        List<Map.Entry<String, String>> map = new ArrayList<>()
        for (Map.Entry<String, String> en : replaceMap.entrySet()) {
            if (line.contains(en.key)) {
//                println "replaceMap 中 对应的 数据 -----" + en
                map.add(en)
            }
        }
        //根据 key 的长度 排序  长 --> 短
        Collections.sort(map, new Comparator<Map.Entry<String, String>>() {
            @Override
            int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
                if (o1.key.length() > o2.key.length()) {
                    return -1;
                } else if (o1.key.length() < o2.key.length()) {
                    return 1;
                }
                return 0
            }
        })

        return map
    }


    private void handleSrcFile(File file) {
        StringBuffer sb = new StringBuffer()
        String str = null
//        println "获取到的 数据 -----" + replaceMap.toString()
        file.eachLine("UTF-8")  { line ->
//            println "获取到的 数据 -----" + line
            if (null != line && !StringUtils.isEs(line.toString()) && !line.startsWith("import") && !line.startsWith("package")) {
                //代码 顶部 import package 依赖 不用替换
                if (null != str) {
                    String str1 = line.trim().substring(line.trim().lastIndexOf(" "), line.trim().lastIndexOf(";"))
//                    println "截取到的  字符----- " + str1.trim()
                    line = StringUtils.replaceCharacter(line, str1.trim(), " " + str)
                    replaceMap.put(str1.trim(), str)
                    str = null

                }
                List<Map.Entry<String, String>> entry = getString(line)
//                println "在map中 找到的数据 --" + line + "---" + entry.toString()
                line = modificationStr(line)
                for (i in 0..<entry.size()) {
                    Map.Entry<String, String> character = entry.get(i)
                    if (line.contains(character.key)) {
                        line = StringUtils.replaceCharacter(line, character.key, character.value)
                        if (line.contains("@BindView(")) {
                            str = character.value
                        }
                    }
                }
                if (map.size() > 0) {
                    for (Map.Entry<String, String> en : map.entrySet()) {
                        line = StringUtils.replaceCharacter(line, en.key, en.value);
                    }
                    map.clear()
                }
                entry.clear()
            }
//            println "替换后的 字符 -----" + line
            sb.append(line + "\r\n")
        }

        file.write(sb.toString(), "UTF-8")// 写回文件
    }

    Map<String, String> map = new HashMap<>();
    /**
     * 先把 其他引用更改 在 后边 更改回来
     * @param line
     * @param sexg
     * @return
     */
    private String modificationLine(String line, String sexg) {
        Matcher matcher = line =~ sexg
        while (matcher.find()) {
            String oldResName = matcher.group(6)
            String newName = getNameAutomatically.getMultiLetter(5);
            line = line.replaceAll(oldResName, newName)
            map.put(newName, oldResName)
        }

        return line
    }
    /**
     * 去除 其他 引用
     * @param line
     * @return
     */
    private String modificationStr(String line) {
        line = modificationLine(line, Constant.JAVA_REGEX)
        line = modificationLine(line, Constant.DRAWABLE_REGEX)
        line = modificationLine(line, Constant.ANIM_REGEX)
        line = modificationLine(line, Constant.STRING_REGEX)

        return line
    }

    private void handleResFile(Set<String> set, regex) {

        for (i in 0..<set.size()) {
            boolean hasUpdate = false                 // 是否有修改
            StringBuilder sb = new StringBuilder()
            File file = new File(set[i])
            file.eachLine("UTF-8") { line ->
//                println "读取到的 数据 ${line.toString()}"
                Matcher matcher = line =~ regex
                StringBuffer tSb = new StringBuffer()
                while (matcher.find()) {
                    String oldResName = matcher.group(2)
                    String newResName = replaceMap.get(oldResName)
                    if (StringUtils.isEs(newResName)) {
                        newResName = getNameAutomatically.getAutomatically()
                        replaceMap.put(oldResName, newResName)
                    }
//                    println "获取到的 旧id ${oldResName} --------------------- 新id------ ${newResName}"
                    hasUpdate = true
                    matcher.appendReplacement(tSb, "\$1$newResName") // 拼接 保留$1分组,替换组2,保留组3
                }
                if (tSb.length() > 0) {                         // 如果包含了，则重新赋值line，并拼接余下部分
                    matcher.appendTail(tSb)
                    hasUpdate = true
                    line = tSb.toString()
                }

                sb.append(line).append("\r\n")
            }

            // 有修改了，才重新写入文件
            if (hasUpdate) {
                file.write(sb.toString(), "UTF-8")
            }
        }
    }
}

package com.github.better.replaceUrl.replace;

import com.github.better.replaceUrl.UrlNewConfiguration;
import com.github.better.replaceUrl.base.BaseUrlReplace;
import com.github.better.tools.FileTools;
import com.github.better.tools.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

/**
 * Bean 依赖 更改
 */
public class BeanQuoteReplace extends BaseUrlReplace {


    private Map<String, String> mBeadNameList;

    /**
     * 读取到的 每一行 的回调
     *
     * @param str 一行 代码
     * @return
     */
    @Override
    public String replaceStr(String str) {
        String str1 = str.replace("*", "").trim();
        if (StringUtils.isEs(str1)) {
            return str;
        }
        Map<String, String> entry = getString(str);
        if (null != entry && entry.size() > 0) {
            for (Map.Entry<String, String> en : mBeadNameList.entrySet()) {
                str = str.replaceAll(en.getKey().trim(), en.getValue().trim());
            }
        }
        return str;
    }

    public void replaceCode(Map<String, String> mBeadNameList, ArrayList<String> listFileName) {
        this.mBeadNameList = mBeadNameList;
        listFileName.clear();
        for (String str : UrlNewConfiguration.srcFolderPath){
            FileTools.getFileName(str, listFileName);
        }
        for (int i = 0; i < listFileName.size(); i++) {
            replaceSrcDir(new File(listFileName.get(i)));
        }
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     *
     * @param line
     * @return
     */
    private Map<String, String> getString(String line) {
        Map<String, String> mBeadNa = new HashMap<>();

        for (Map.Entry<String, String> en : mBeadNameList.entrySet()) {
            if (line.contains(en.getKey().trim())) {
//                println() "replaceMap 中 对应的 数据 -----" + en
                mBeadNa.put(en.getKey().trim(), en.getValue());
            }
        }

        if (mBeadNa.size() == 0) {
            return null;
        }
        return mBeadNa;

    }

}



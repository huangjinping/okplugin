package com.github.better.replacecode;

import com.github.better.replacecode.data.IgnoreData;
import com.github.better.tools.StringUtils;


import java.util.Random;

public class NewStr {
    /**
     * 命名长度
     */
    private final static int Max = 15;
    private final static int min = 5;
    private static NewStr instance;

    private NewStr() {

    }

    char[] c = {
            'a',
            'b',
            'c',
            'd',
            'e',
            'f',
            'g',
            'h',
            'i',
            'j',
            'k',
            'l',
            'm',
            'n',
            'o',
            'p',
            'q',
            'r',
            's',
            't',
            'u',
            'v',
            'w',
            'x',
            'y',
            'z',
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '_'};

    public static NewStr getInstance() {
        if (instance == null) {
            instance = new NewStr();
        }
        return instance;
    }

    Random r = new Random();

    public String generateNewString() {
        int randNumber = r.nextInt(Max - min + 1) + min;
        StringBuffer string = new StringBuffer();
        for (int i = 0; i < randNumber; i++) {
            int num;
            if (i == 0) {
                num = r.nextInt(51);
            } else {
                num = r.nextInt(63);
            }
            string.append(c[num]);
        }
        if (IgnoreData.isEligibility(string.toString())) {
            return generateNewString();
        }
        return string.toString();
    }

    /**
     * 首字母 大写
     */
    public String getInitialsString() {
        return StringUtils.toUpperCaseStr(generateNewString());
    }

    /**
     * 首字母 小写
     */
    public String getLowerCaseString() {
        return StringUtils.toLowerCaseStr(generateNewString());
    }

    /**
     * 全部大写
     */
    public String getAllCapsString() {
        return generateNewString().toUpperCase();
    }

    /**
     * 全部小写
     */
    public String getAllLowercaseString() {
        return generateNewString().toLowerCase();
    }

}

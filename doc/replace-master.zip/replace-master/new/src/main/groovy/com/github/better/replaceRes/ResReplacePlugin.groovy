package com.github.better.replaceRes

import com.github.better.NewConfiguration
import com.github.better.replaceRes.folder.*
import com.github.better.replaceRes.values.ValuesReplace
import com.github.better.tools.ConfigurationProcessing
import org.gradle.api.Project
/**
 * 资源名 修改
 */
class ResReplacePlugin{

    public void startPlugin(Project project){
        //添加 config
        project.extensions.create('resConfig', ResNewConfiguration.class)
        //替换 资源 名称
        project.tasks.create(["name": "replaceResName", "group": "resourceTools"]) {
            doLast {
                if (!project.android) {
                    throw new IllegalStateException('Must apply \'com.android.application\' or \'com.android.library\' first!')
                }

                if (project.resConfig == null) {       // check config
                    throw new IllegalArgumentException(
                            'replaceRes gradle plugin "resConfig DSL" config can not be null.')
                }


                // === System default
//                String sourceFolder = project.android.sourceSets.main.java.srcDirs[0].getAbsolutePath()
//                String resFolder = project.android.sourceSets.main.res.srcDirs[0].getAbsolutePath()
//                String manifestFilePath = project.android.sourceSets.main.manifest.srcFile.getAbsolutePath()
//                String assetsFilePath = project.android.sourceSets.main.assets.srcDirs[0].getAbsolutePath()
                long startTime = System.currentTimeMillis()     // startTime

                // === User settings
                def config = project.resConfig
                String[] str = config.namingScheme.split("_")
                if (config.namingScheme != null || config.namingScheme.trim().length() != 0) {
                    if (str[0].contains(NewConfiguration.RANDOM_NUMBER)) {
                        throw new IllegalArgumentException(
                                'The first line cannot be a number (第一行不能为数字)')
                    }
                }

//                if (config.srcFolderPath != null && config.srcFolderPath.trim().length() > 0) {
//                    sourceFolder = config.srcFolderPath
//                }
//                if (config.resFolderPath != null && config.resFolderPath.trim().length() > 0) {
//                    resFolder = config.resFolderPath
//                }
//                if (config.manifestFilePath != null && config.manifestFilePath.trim().length() > 0) {
//                    manifestFilePath = config.manifestFilePath
//                }

                // === print all settings

                println(">>>>>> old_prefix: ${config.old_prefix}")
                println(">>>>>> new_prefix: ${config.new_prefix}")
//                println(">>>>>> srcFolder : ${sourceFolder}")
//                println(">>>>>> resFolder : ${resFolder}")
//                println(">>>>>> AndroidManifest.xml file path : ${manifestFilePath}")
//                println(">>>>>> addrts file path : ${assetsFilePath}")

                // === do work
                println "++++++++++++++++++++++ Start replace Android resources..."

                ResNewConfiguration.init(
                        config.new_prefix,
                        config.old_prefix,
                        ConfigurationProcessing.getSrcAdders(project,config.processingModule),
                        ConfigurationProcessing.getResAdders(project,config.processingModule),
                        ConfigurationProcessing.getManifestAdders(project,config.processingModule), config.namingScheme,ConfigurationProcessing.getAssetsAdders(project,config.processingModule))
                doWork()

                println("++++++++++++++++++++++ Finish replace resouces name, Total time: ${(System.currentTimeMillis() - startTime) / 1000} ")
            }
        }
    }

    private def doWork() {
        // 1. layout
        LayoutReplace layoutReplace = new LayoutReplace();
        layoutReplace.replaceThis();

//        // 2. drawable
        DrawableReplace drawableReplace = new DrawableReplace();
        drawableReplace.replaceThis();
//
//
//        // 3.  color
//        ColorReplace colorReplace = new ColorReplace(config);
//        colorReplace.replaceThis();
//
//
//        // 4.  Anim
        AnimReplace anim = new AnimReplace();
        anim.replaceThis();
//
//        // 5.  menu
        MenuReplace menuReplace = new MenuReplace();
        menuReplace.replaceThis();
//
//        // 6.  mipmap
        MipmapReplace mipmapReplace = new MipmapReplace();
        mipmapReplace.replaceThis();
//
//        // 7. raw
        RawReplace rawReplace = new RawReplace();
        rawReplace.replaceThis();
//
//        // 8. xml
        XmlReplace xmlReplace = new XmlReplace();
        xmlReplace.replaceThis();

        // 8. assets
//        AssetsReplace assetsReplace = new AssetsReplace();
//        assetsReplace.replaceThis();

        ////////////// all values  types ////////////////////
        // === 9. values test not support attrs
        ValuesReplace valuesReplace = new ValuesReplace();
        valuesReplace.replaceValues(ValuesReplace.ALL_VALUES_TYPES);
    }
}
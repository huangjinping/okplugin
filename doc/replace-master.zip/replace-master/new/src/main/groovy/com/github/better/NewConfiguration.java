package com.github.better;

import java.util.List;

public  class NewConfiguration {
    /**
     * 数字
     */
    public final static String RANDOM_NUMBER = "RANDOMNUMBER";
    /**
     * 字母
     */
    public final static String RANDOM_LETTERS = "RANDOMLETTERS";

    /**
     * 资源文件目录
     */
    public static List<String> resFolderPath;
    /**
     * 源代码目录
     */
    public static List<String> srcFolderPath;

    /**
     * id 命名规则
     *
     * @param namingScheme
     */
    public  String namingScheme = "";

    /**
     * 需要 处理的 模块 无 默认处理 app 模块
     *
     * @param namingScheme
     */
    public  List<String> processingModule ;



    private static NewConfiguration INSTANCE = null;



    public static NewConfiguration getInstance() {
        if (INSTANCE != null) {
            return INSTANCE;
        }
        INSTANCE = new NewConfiguration();
        return INSTANCE;
    }

    public static void init(List<String> resFolderPaths, List<String> srcFolderPaths, String namingSchemes) {
        resFolderPath = resFolderPaths;
        srcFolderPath = srcFolderPaths;
        getInstance().namingScheme = namingSchemes;
    }
}

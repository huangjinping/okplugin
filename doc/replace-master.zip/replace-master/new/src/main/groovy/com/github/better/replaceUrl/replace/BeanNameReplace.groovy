package com.github.better.replaceUrl.replace

import com.github.better.replaceUrl.UrlNewConfiguration
import com.github.better.tools.FileTools
import com.github.better.tools.StringUtils
import groovy.io.FileType
/**
 * 出参 替换
 */
public class BeanNameReplace {

    ArrayList<String> listFileName;

    /**
     * apiurl 数据类 名
     */
    private Map<String, String> beanNameList;


    /**
     * 文件重命名，处理各种文件的重命名
     */
    protected void renameFile() {
//        println("---------------配置目录：${UrlNewConfiguration.srcFolderPath}")
        UrlNewConfiguration.srcFolderPath.each { dirs ->
            new File(dirs).traverse(type: FileType.FILES) { it ->
                String fileName = it.name
//            println("--------------- 原有文件名：${fileName}")
                if (!it.isFile()) {
                    return
                }
                String name = fileName.substring(0, fileName.lastIndexOf(".")).trim();
                Map.Entry<String, String> en = getString1(name);
                // 只替换指定的资源
                if (null != en) {
//                println("--------------- 原有文件名：${fileName}")
                    //后缀
                    String newName = fileName.replace(name, en.value).trim();
//                    println("--------------- 新文件名：${newName}------ 旧文件名：${fileName}")
                    if (!FileTools.rename(it, newName)) {
                        println("--------------- ${it.name} 重命名失败！，请手动修改成：${newName}")
                    }
                }
            }
        }
    }

    private Map.Entry<String, String> getString1(String line) {
        if (StringUtils.isEs(line)) {
            return null;
        }
        for (Map.Entry<String, String> en : beanNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.trim() == en.getKey().trim()) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en;
            }
        }
        return null;
    }

    public void replaceCode(Map<String, String> beanNameList, ArrayList<String> listFileName) {
        this.beanNameList = beanNameList;
        this.listFileName = listFileName;

        renameFile();
        listFileName.clear();
        UrlNewConfiguration.srcFolderPath.each {
            FileTools.getFileName(it, listFileName);
        }

        new BeanQuoteReplace().replaceCode(beanNameList, listFileName);
    }
}


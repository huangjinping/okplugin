package com.github.better.replaceRes;

import com.github.better.NewConfiguration;

import java.util.List;

public class ResNewConfiguration extends NewConfiguration {
    /**
     * 新的资源前缀
     */
    public static String new_prefix = "";
    /**
     * 老的资源前缀，取值说明如下：
     * <p>
     * 1. 使用空字符串：
     * 比如：new_prefix 为 'mae_',  module_main_activity.xml 会被替换成 mae_module_main_activity.xml
     * 2. 取值字符串时：
     * 比如：old_prefix='module_', new_prefix='mae_', module_main_activity.xml 会被替换成 mae_main_activity.xml
     */
    public static String old_prefix = "";

    /**
     * 清单文件路径
     */
    public static List<String> manifestFilePath ;

    /**
     * assets文件目录
     */
    public static List<String> assetsFolderPath ;


    private static ResNewConfiguration INSTANCE = null;

    public static ResNewConfiguration getInstance() {
        if (INSTANCE != null) {
            return INSTANCE;
        }
        INSTANCE = new ResNewConfiguration();
        return INSTANCE;
    }


    public static void init(String new_prefixs, String old_prefixs, List<String> srcFolderPaths, List<String> resFolderPaths, List<String> manifestFilePaths, String namingSchemes, List<String> assetsFolderPaths) {
        new_prefix = new_prefixs;
        old_prefix = old_prefixs;
        srcFolderPath = srcFolderPaths;
        resFolderPath = resFolderPaths;
        manifestFilePath = manifestFilePaths;
        assetsFolderPath = assetsFolderPaths;
        getInstance().namingScheme = namingSchemes;
    }

}

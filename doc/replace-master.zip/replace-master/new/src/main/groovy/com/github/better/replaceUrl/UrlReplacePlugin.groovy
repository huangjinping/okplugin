package com.github.better.replaceUrl

import com.github.better.replaceUrl.replace.CarryOut
import com.github.better.tools.ConfigurationProcessing
import org.gradle.api.Project
/**
 *
 */
class UrlReplacePlugin {

    public void startPlugin(Project project) {
        //添加 config
        project.extensions.create('urlConfig', UrlNewConfiguration.class)
        // 替换 接口 相关 数据
        project.tasks.create(["name": "replaceUrl", "group": "resourceTools"]) {
            doLast {
                if (!project.android) {
                    throw new IllegalStateException('Must apply \'com.android.application\' or \'com.android.library\' first!')
                }

                if (project.urlConfig == null) {       // check config
                    throw new IllegalArgumentException(
                            'replaceRes gradle plugin "resConfig DSL" config can not be null.')
                }

                // === System default
                String sourceFolder = project.android.sourceSets.main.java.srcDirs[0].getAbsolutePath()
                String resFolder = project.android.sourceSets.main.res.srcDirs[0].getAbsolutePath()
                String manifestFilePath = project.android.sourceSets.main.manifest.srcFile.getAbsolutePath()

                long startTime = System.currentTimeMillis()     // startTime

                // === User settings
                def config = project.urlConfig
                if (config.urlTextPath == null || config.urlTextPath.trim().length() == 0) {
                    throw new IllegalArgumentException(
                            'the [urlTextPath] can not be null (必须配置 接口文档 名称)')
                }
                if (config.apiClass == null || config.apiClass.trim().length() == 0) {
                    throw new IllegalArgumentException(
                            'the [apiClass] can not be null (必须配置 接口类  地址)')
                }
                config.apiClass = config.apiClass.collectReplacements { it == '.' ? '\\' : null }
                // === print all settings
                println(">>>>>> srcFolder : ${sourceFolder}")
                println(">>>>>> resFolder : ${resFolder}")
                println(">>>>>> urlJSonFolder : ${System.getProperty("user.dir") + "\\" + config.urlTextPath}")
                println(">>>>>> AndroidManifest.xml file path : ${manifestFilePath}")
                println(">>>>>> apiClass : ${sourceFolder + "\\" + config.apiClass + '.java'}")


                // === do work
                println "++++++++++++++++++++++ Start replace Android resources..."

                config.apiClass = sourceFolder + "\\" + config.apiClass + '.java'
                config.srcFolderPath = ConfigurationProcessing.getSrcAdders(project, config.processingModule)
                config.resFolderPath = ConfigurationProcessing.getResAdders(project, config.processingModule)

                println "++++++++ 赋值完成 ..."
                println "++++++++ 赋值完成 ... "+config.srcFolderPath
                println "++++++++ 赋值完成 ..." +config.resFolderPath

                //api 类 修改
                new CarryOut().replaceUrl()

                println("++++++++++++++++++++++ Finish replace resouces name, Total time: ${(System.currentTimeMillis() - startTime) / 1000} ")
            }
        }
    }
}
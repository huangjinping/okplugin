package com.github.better.replaceUrl.base;

import com.github.better.replaceUrl.UrlNewConfiguration;
import com.github.better.tools.StringUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public abstract class BaseUrlReplace {
    /**
     * 源代码路径
     */
    protected String uRLDir;
    /**
     * 资源文件路径
     */
    protected File apiDir;


    public BaseUrlReplace() {
        this.uRLDir = UrlNewConfiguration.urlTextPath;
        this.apiDir = new File(UrlNewConfiguration.apiClass);
    }

    // ====== 源代码中的部分  start =============================================

    /**
     * 替换 src 源代码目录中的资源名
     *
     * @param file 源代码目录
     */
    protected void replaceSrcDir(File file) {
        if (file.exists()) {
            if (file.isDirectory()) {
//                System.out.println("失败 没有找到api 文件   是个文件夹  请 更改为 .java-----" + file.getName());
            } else {
                if (file.getName().endsWith(".java") || file.getName().endsWith(".kt")) {
                    // only .java or .kt files
                    handleSrcFile(file);
                }
            }
        } else {
//            System.out.println("失败 没有找到api 文件 -----" + file.getName());
        }
    }

    private void handleSrcFile(File file) {
        BufferedReader reader = null;
        StringBuffer sb = new StringBuffer();
        try {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
//            System.out.println("以行为单位读取文件内容，一次读一整行：");
            reader = new BufferedReader(isr);
            String tempString = null;
            int line = 1;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                // 显示行号
//                System.out.println("line " + line + ": " + tempString);
                sb.append(replaceStr(tempString) + "\r\n");
                line++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        addFile(tail(sb.toString()), file);
    }


    /**
     * 1、写入文件  覆盖
     */
    public boolean addFile(String string, File file) {

        PrintStream stream = null;
        try {
            byte[] bs = string.getBytes("UTF-8");
            string = new String(bs, "UTF-8");
            stream = new PrintStream(file.getPath());//写入的文件path
            stream.print(string);//写入的字符串
            stream.close();
            return true;
        } catch (FileNotFoundException | UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
        return false;
    }


    /**
     * 读取 字符串 并处理
     *
     * @param str
     * @return
     */
    public abstract String replaceStr(String str);

    /**
     * 尾部 处理
     *
     * @return
     */
    public String tail(String string) {
        return string;
    }

    /**
     * 替换的 新方法名  首字母 为 小写
     */
    protected String substitutionMethodName(String rule, String name) {
        return StringUtils.toLowerCaseStr(rule.replace("_", StringUtils.toUpperCaseStr(name)));
    }

    /**
     * 替换的 新方法名  首字母 为 大写
     */
    protected String substitutionMethodName1(String rule, String name) {
        return StringUtils.toUpperCaseStr(rule.replace("_", StringUtils.toUpperCaseStr(name)));
    }

}

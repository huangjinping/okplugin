package com.github.better.replacecode.data;

/**
 * 替换 数据
 */
public class ReplaceData {
    String oldName;
    String newName;
    /**
     * true  作用域  公共
     * false 作用域  private
     */
    boolean replace;

    public String getOldName() {
        return oldName;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }

    public String getNewName() {
        return newName;
    }

    public void setNewName(String newName) {
        this.newName = newName;
    }

    public boolean isReplace() {
        return replace;
    }

    public void setReplace(boolean replace) {
        this.replace = replace;
    }

    public ReplaceData(String oldName, String newName, boolean replace) {
        this.oldName = oldName;
        this.newName = newName;
        this.replace = replace;
    }

    @Override
    public String toString() {
        return "ReplaceData{" +
                "oldName='" + oldName + '\'' +
                ", newName='" + newName + '\'' +
                ", replace=" + replace +
                '}';
    }
}

package com.github.better.replaceUrl.replace;

import com.github.better.replaceUrl.base.BaseUrlReplace;
import com.github.better.tools.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

/**
 * 代码 替换  替换
 * <p>
 * <p>
 * 替换 网络框架  成功 失败方法
 * <p>
 * 方法名替换
 */
public class MethodReplace extends BaseUrlReplace {


    private Map<String, String> mBeadNameList;


    /**
     * 读取到的 每一行 的回调
     *
     * @param str 一行 代码
     * @return
     */
    @Override
    public String replaceStr(String str) {
        String str1 = str.replace("*", "").trim();
        if (StringUtils.isEs(str1)) {
            return str;
        } else if (str1.contains("(")) {
            Map.Entry<String, String> entry = getString(str);
            if (null != entry) {
                str = str.replaceAll(entry.getKey().trim(), entry.getValue().trim());
            }
        }

        return str;
    }

    public void replaceCode(Map<String, String> mBeadNameList, ArrayList<String> listFileName) {
        this.mBeadNameList = mBeadNameList;
        for (int i = 0; i < listFileName.size(); i++) {
            replaceSrcDir(new File(listFileName.get(i)));
        }
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     *
     * @param line
     * @return
     */
    private Map.Entry<String, String> getString(String line) {
        for (Map.Entry<String, String> en : mBeadNameList.entrySet()) {
            if (line.contains(en.getKey().trim() + "(")) {
//                println() "replaceMap 中 对应的 数据 -----" + en
                int l = line.indexOf(en.getKey().trim() + "(");
                if (line.length() - 1 > l) {
                    String str1 = line.substring(l - 1, l);
                    if (StringUtils.isEs(str1) || ".".equals(str1)) {
                        return en;
                    }
                } else if (line.length() - 1 == l) {
                    return en;
                }
            }
        }
        return null;
    }

}



package com.github.better.replaceUrl;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;

public class TestJson {

    public static List<String> setNameJson() {
        List<String> list = new ArrayList<>();

        list.add("验证版本更新,");
        list.add("获取启动图");
        list.add("获取图验,请求图形验证码");
        list.add("获取字典配置数据项,字典配置项");
        list.add("获取短信验证码");
        list.add("获取语音验证码");
        list.add("银行详细获取接口(编码及名称)");
        list.add("获取短链接信息");
        list.add("生成二维码");
        list.add("上传json数据,5：位置，6：终端信息");
        list.add("上传File数据,已文件流的形式上传文件");
        list.add("基本信息提交,提交基本信息");
        list.add("用户工作信息提交,提交work信息");
        list.add("联系人信息提交,提交联系人信息");
        list.add("用户信息回显,用户联系人信息回显,获取用户信息：紧急联系人,获取用户信息：基本信息人,获取用户信息：工作信息,获取用户信息：银行信息");
        list.add("(nano)识别身份卡正面信息,nano上传身份证正面信息(识别)");
        list.add("(panda)识别身份卡正面信息");
        list.add("(advance)识别身份卡正面信息,Advance识别保存 通用,公共识别Aad卡信息");
        list.add("(nano废弃)人脸识别");
        list.add("(panda)活体前获取token");
        list.add("ocr信息保存,身份识别组合信息保存");
        list.add("获取ocr 数据回显,获取ocr数据回显");
        list.add("公共OCR识别,OCR证件照正面识别,OCR证件照正面识别(公共接口),上传身份证正面信息(识别),nano上传身份证正面信息(识别),通用接口识别保存正面信息,Advance识别保存 通用");
        list.add("人脸前置token接口,活体前获取token,公共获取face前置token信息识别接口,人脸前置token接口（公共接口）");
        list.add("公共人脸比对,公共人脸识别,公共人脸对比接口,人脸对比的信息,校验人脸识别的结果(识别),Advance识别保存Aadhaar卡人脸信息");
        list.add("提交验证银行卡信息,提交验证银行卡,添加银行卡,提交验证银行卡,添加银行卡信息,信息收集,银行卡信息提交,提交bank信息");
        list.add("获取借款试算信息");
        list.add("确认借款");
        list.add("首页多场景");
        list.add("调用风控规则");
        list.add("获取风控规则调用结果,获取风控规则调用结果，不需要应用ID");
        list.add("订单状态同步");
        list.add("初始化应用信息");
        list.add("个人中心银行卡项是否展示");
        list.add("获取银行卡列表");
        list.add("保存选中默认银行卡");
        list.add("验证用户是否注册,验证用户是否注册 0-已注册 1未注册");
        list.add("验证是否当天首次触发短信验证码,判断是否当天首次触发短信验证码");
        list.add("用户注册登录");
        list.add("用户登出,退出登录");
        list.add("用户反馈");
        list.add("订单列表,订单历史列表");
        list.add("重置密码");
        list.add("用户登录");
        list.add("优惠券去使用接口,使用优惠券");
        list.add("获取邀请活动开关");
        list.add("获取用户金币信息");
        list.add("兑换优惠券");
        list.add("邀请用户注册");
        list.add("获取用户金币记录");
        list.add("获取用户邀请记录");
        list.add("获取优惠券列表");
        list.add("兑换记录");
        list.add("跑马灯");
        list.add("贷后订单通知");
        list.add("提现银行卡回显");
        list.add("添加提现银行卡");
        list.add("精品列表");
        list.add("精品点击埋点信息记录,精品点击统计");
        list.add("邀请埋点记录,活动点击来源统计");
        list.add("登录注册埋点记录");
        list.add("订单详情接口,获取还款详情");
        list.add("充值还款");
        list.add("获取还款方式,获取还款支付通道-新");
        list.add("展期试算");
        list.add("申请展期订单");
        list.add("验证寻囊有效期,验证寻囊是否在有效期内");
        list.add("(ad)银行卡验证人脸比对,银行卡验证人脸对比 advance");
        list.add("信用报告(待定),获取信用报告");
        list.add("取消自动借款,取消进件");
        list.add("修改试算信息,修改订单信息");
        list.add("上传Inpays-还款短信");
        list.add("生cheng预约单,创建预约单");
        list.add("预约单列表");
        list.add("取消预约单");
        list.add("是否需要预约,验证申请单流程");
        list.add("UPI-查询订单状态,查询 订单状态");
        return list;
    }

    /**
     *
     * 入参 转 出参 的 键值对
     * @return
     */
    public static AbstractMap.SimpleEntry<String, String> getCorrespondence() {
        String str = "基本信息提交,提交基本信息,联系人信息提交,提交联系人信息,用户工作信息提交,银行卡信息提交";

        String str1 = "用户信息回显,用户联系人信息回显,获取用户信息：紧急联系人,获取用户信息：基本信息人,获取用户信息： 工作信息,获取用户信息： 银行信息";

        AbstractMap.SimpleEntry<String, String> map = new AbstractMap.SimpleEntry<String, String>(str, str1);

        return map;
    }
}

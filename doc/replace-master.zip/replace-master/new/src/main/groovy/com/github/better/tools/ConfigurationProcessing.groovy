package com.github.better.tools


import org.gradle.api.Project

class ConfigurationProcessing {
    /**
     * 获取  src  地址
     */

    public static List<String> getSrcAdders(Project project, List<String> processingModule) {
        List<String> list = new ArrayList<String>();
        if (null != processingModule && processingModule.size() > 0) {
            project.getRootProject().getSubprojects().each {
                if (it.projectDir != null) {
                    String fileName = it.projectDir.getAbsolutePath() + "\\src\\main\\java";

                    if (FileTools.existsAny(fileName)) {
                        boolean flag = false
                        processingModule.each { str ->
                            if (it.projectDir.name == str) {
                                flag = true
                            }
                        }
                        if (flag) {
                            list.add(fileName)
                        }
                    }
                }
            }
        } else {
            list.add(project.android.sourceSets.main.java.srcDirs[0].getAbsolutePath());
        }
        return list
    }


    /**
     * 获取  res  地址
     */

    public static List<String> getResAdders(Project project, List<String> processingModule) {
        List<String> list = new ArrayList<String>();
        if (null != processingModule && processingModule.size() > 0) {
            project.getRootProject().getSubprojects().each {
                if (it.projectDir != null) {
                    String fileName = it.projectDir.getAbsolutePath() + "\\src\\main\\res";
                    println "所以子项目 projectDir: ${fileName}"
                    println "所以子项目 的 res projectDir: ${fileName}"
                    if (FileTools.existsAny(fileName)) {
                        boolean flag = false
                        processingModule.each { str ->
                            if (it.projectDir.name == str) {
                                flag = true
                            }
                        }
                        if (flag) {
                            list.add(fileName)
                        }
                    }
                }
            }
        } else {
            list.add(project.android.sourceSets.main.res.srcDirs[0].getAbsolutePath());
        }
        return list
    }

    /**
     * 获取  Manifest  地址
     */

    public static List<String> getManifestAdders(Project project, List<String> processingModule) {
        List<String> list = new ArrayList<String>();
        if (null != processingModule && processingModule.size() > 0) {
            project.getRootProject().getSubprojects().each {
                if (it.projectDir != null) {
                    String fileName = it.projectDir.getAbsolutePath() + "\\src\\main\\AndroidManifest.xml";

                    if (FileTools.existsAny(fileName)) {
                        boolean flag = false
                        processingModule.each { str ->
                            if (it.projectDir.name == str) {
                                flag = true
                            }
                        }
                        if (flag) {
                            list.add(fileName)
                        }
                    }
                }
            }
        } else {
            list.add(project.android.sourceSets.main.manifest.srcFile.getAbsolutePath());
        }
        return list
    }
    /**
     * 获取  Assets  地址
     */

    public static List<String> getAssetsAdders(Project project, List<String> processingModule) {
        List<String> list = new ArrayList<String>();
        if (null != processingModule && processingModule.size() > 0) {
            project.getRootProject().getSubprojects().each {
                if (it.projectDir != null) {
                    String fileName = it.projectDir.getAbsolutePath() + "\\src\\main\\assets";

                    if (FileTools.existsAny(fileName)) {
                        boolean flag = false
                        processingModule.each { str ->
                            if (it.projectDir.name == str) {
                                flag = true
                            }
                        }
                        if (flag) {
                            list.add(fileName)
                        }
                    }
                }
            }
        } else {
            list.add(project.android.sourceSets.main.assets.srcDirs[0].getAbsolutePath());
        }
        return list
    }

    /**
     * 获取  全路径  地址
     */
    public static List<String> getFullPath(Project project, List<String> processingModule) {
        List<String> list = new ArrayList<String>();
        if (null != processingModule && processingModule.size() > 0) {
            project.getRootProject().getSubprojects().each {
                if (it.projectDir != null) {
                    String fileName = it.projectDir.getAbsolutePath() + "\\src\\main\\java";
                    ArrayList<String> listFileName = new ArrayList<String>();
//                    println "获获取到的 java文件" + fileName
                    FileTools.getFileName(fileName, listFileName)
                    listFileName.each { fiName ->
                        if (FileTools.existsAny(fiName)) {
                            boolean flag = false
                            processingModule.each { str ->
//                                println "获获取到的java 文件" + fiName + "  需要处理的文件" + str
                                if (fiName.replaceAll('\\\\', ".").contains(str)) {
                                    flag = true
                                }
                            }
                            if (flag) {
                                println "获获取到的 java文件 全路径" + fiName
                                list.add(fiName)
                            }
                        }
                    }

                }
            }
        } else {
            return null
        }
        return list
    }
    /**
     * 获取  全路径  地址
     */
    public static List<String> getCalssPath(Project project, List<String> processingModule) {
        List<String> list = new ArrayList<String>();
        if (null != processingModule && processingModule.size() > 0) {
            project.getRootProject().getSubprojects().each {
                if (it.getBuildDir() != null) {
                    String fileName = it.getBuildDir().getAbsolutePath()+"\\intermediates\\javac"
//                    println "获获取到的 class文件" + fileName
                    ArrayList<String> listFileName = new ArrayList<String>();
                    FileTools.getFileName(fileName, listFileName)
                    listFileName.each { fiName ->
                        if (FileTools.existsAny(fiName)) {
                            boolean flag = false
                            processingModule.each { str ->
                                String fileNamed =  fiName.replaceAll('\\\\', ".")
//                                println "获获取到的 class 文件" + fiName + "  需要处理的文件" + str

                                if (fileNamed.contains(str)&& !StringUtils.frontCode1(fileNamed,str)) {
                                    flag = true
                                }
                            }
                            if (flag) {
//                                println "获获取到的 class 文件 全路径" + fiName
                                list.add(fiName)
                            }
                        }
                    }

                }
            }
        } else {
            return null
        }
        return list
    }




}
package com.github.better.replaceUrl.replace;

import com.github.better.replaceUrl.UrlNewConfiguration;
import com.github.better.replaceUrl.base.BaseUrlReplace;
import com.github.better.replaceUrl.bean.RequestArgsData;
import com.github.better.replaceUrl.bean.UrlDate;
import com.github.better.replaceUrl.getData.GetEmployDate;
import com.github.better.tools.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * api  url  替换
 */
public class CarryOut extends BaseUrlReplace {

    List<UrlDate> list = null;
    /**
     * bean 字段名  数据
     */
    private Map<String, List<RequestArgsData>> mBeadNameList = new HashMap<>();

    /**
     * apiurl 方法名  替换数据
     */
    private Map<String, String> MethodNameList = new HashMap<>();

    /**
     * apiurl 数据类 名
     */
    private Map<String, String> beanNameList = new HashMap<>();

    UrlDate replaceUrlDate = null;
    int index = -1;

    @Override
    public String replaceStr(String str) {
        String str1 = str.replace("*", "").trim();
        str1 = str1.replace("/", "").trim();
        if ("/".equals(str1) || "//".equals(str1) || StringUtils.isEs(str1)) {
            return str;
        }

        float similarity = 0;
        if (!str.contains("@POST") && !str.contains("Observable") && !str.contains("@param") && !str.contains("@return")) {

            for (int i = 0; i < list.size(); i++) {
                UrlDate urlDate = list.get(i);
                float similarityd = StringUtils.levenshtein1(urlDate.getName(), str1);
                if (similarityd == 1) {
                    index = i;
                    break;
                } else if (similarityd >= 0.8 && similarityd > similarity) {
                    index = i;
                    similarity = similarityd;
                }
            }
            if (index != -1) {
//                System.out.println("基准 ------------------------------" + list.get(index).getName() + "----apiUrl中的---" + str);
                replaceUrlDate = list.get(index);
            }
        }
        if (null != replaceUrlDate) {
            if (str.contains("@POST")) {
//                System.out.println("替换的url ------------------------------" + replaceUrlDate.getName() + "-------" + replaceUrlDate.getUrl());
                return StringUtils.cutOutReplace("@POST(\"", "\")", str, replaceUrlDate.getUrl());
            }
//            if (replaceUrlDate.getResponseArgs().size() != 0) {
//                if (str.contains(">>")) {
//                    String mBeanMame = StringUtils.getStringFrom("<", ">>", str);
//                    if (!"String".equals(mBeanMame)) {
////                        System.out.println("获取到的 bean 类 -----" + mBeanMame);
//                        if (mBeanMame.contains(">")) {
//                            mBeadNameList.put(mBeanMame.replaceAll(">", ""), replaceUrlDate.getResponseArgs());
//                        } else {
//                            mBeadNameList.put(mBeanMame, replaceUrlDate.getResponseArgs());
//                        }
//                    }
//                }
//            }

            //获取 Api url 的方法名 并修改
            if (str.contains(">>") && str.contains("(")) {
                String mBeanMame = StringUtils.getStringFrom2(">>", "(", str);

//                System.out.println("获取到的 url  -----" + replaceUrlDate.getUrl());
                String jsonName = replaceUrlDate.getUrl().substring(replaceUrlDate.getUrl().lastIndexOf('/') + 1);
                jsonName = StringUtils.removeSpecialCharacters(jsonName);
                //是否有 一个接口  两个调用方法的问题
                Map.Entry<String, String> entry = getString1(jsonName.trim());
                if (null != entry) {
                    jsonName = jsonName + getMultiLetter(3);
                }
                String newName = substitutionMethodName(UrlNewConfiguration.apiUrlMethodName, jsonName);
//                System.out.println("获取到的 旧方法名  -----" + mBeanMame + "-------新方法名-----" + newName);
                str = str.replace(mBeanMame, newName);
                MethodNameList.put(mBeanMame.trim(), jsonName.trim());
            }

            //获取 Api url 的 数据 类名
            if (str.contains(">") && str.contains("<")) {
                String mBeanMame = null;
                if (str.contains("Map<")) {
                    mBeanMame = str.substring(0, str.indexOf("Map<"));
                    mBeanMame = StringUtils.getStringFrom3("<", ">", mBeanMame);
                } else {
                    mBeanMame = StringUtils.getStringFrom3("<", ">", str);
                }

//                System.out.println("获取 Api url 的 数据 类名(1层)  -----" + mBeanMame);
                mBeanMame = StringUtils.getStringFrom3("<", ">", mBeanMame);
//                System.out.println("获取 Api url 的 数据 类名(2层)  -----" + mBeanMame);
                if (!StringUtils.isEs(mBeanMame) && mBeanMame.contains("List<")) {
                    mBeanMame = StringUtils.getStringFrom3("<", ">", mBeanMame);
                    if (!"String".equals(mBeanMame)) {
                        String jsonName = replaceUrlDate.getUrl().substring(replaceUrlDate.getUrl().lastIndexOf('/') + 1);
                        jsonName = StringUtils.removeSpecialCharacters(jsonName);
                        //是否有 一个接口  两个调用方法的问题
                        Map.Entry<String, String> entry = getString2(mBeanMame.trim());
                        String newName = null;

                        if (null != entry) {
                            newName = entry.getValue();
                        } else {
                            newName = substitutionMethodName1(UrlNewConfiguration.apiUrlBeanName, jsonName);
                            if (beanNameList.containsValue(newName)) {
                                newName = substitutionMethodName1(UrlNewConfiguration.apiUrlBeanName, jsonName + getMultiLetter(3));
                            }
                            beanNameList.put(mBeanMame.trim(), newName.trim());

                        }
//                        System.out.println("对应的出参数据---" + replaceUrlDate.getResponseArgs());
                        AddDataRelationship(mBeanMame, replaceUrlDate.getResponseArgs());
                        str = str.replace(mBeanMame, newName);

                    }
                } else if (!StringUtils.isEs(mBeanMame) && !"String".equals(mBeanMame)) {
                    String jsonName = replaceUrlDate.getUrl().substring(replaceUrlDate.getUrl().lastIndexOf('/') + 1);
                    jsonName = StringUtils.removeSpecialCharacters(jsonName);
                    //是否有 一个接口  两个调用方法的问题
                    Map.Entry<String, String> entry = getString2(mBeanMame.trim());
                    String newName = null;
                    if (null != entry) {
                        newName = entry.getValue();
                    } else {
                        newName = substitutionMethodName1(UrlNewConfiguration.apiUrlBeanName, jsonName);
                        if (beanNameList.containsValue(newName)) {
                            newName = substitutionMethodName1(UrlNewConfiguration.apiUrlBeanName, jsonName + getMultiLetter(3));
                        }
                        beanNameList.put(mBeanMame.trim(), newName.trim());
                    }
//                    System.out.println("对应的出参数据---" + replaceUrlDate.getResponseArgs());
                    AddDataRelationship(mBeanMame, replaceUrlDate.getResponseArgs());
                    str = str.replace(mBeanMame, newName);
                }
            }

            //入参  字段名 修改
            if (str.contains("@Query(") && replaceUrlDate.getRequestArgs().size() != 0) {
                System.out.println(str + "---------" + replaceUrlDate.getRequestArgs());
                int count = new StringUtils().countStr(str, "@Query(\"");
                if (count == 1 && replaceUrlDate.getRequestArgs().size() == 1) {
                    String old1 = str.substring(str.indexOf("@Query(\"") + "@Query(\"".length(), str.indexOf("\")"));
                    str = str.replace(old1, StringUtils.stringMatch1(old1, replaceUrlDate.getRequestArgs().get(0).getName()));
                } else if (count == 1) {
                    String old1 = str.substring(str.indexOf("@Query(\"") + "@Query(\"".length(), str.indexOf("\")"));
                    for (int i = 0; i < replaceUrlDate.getRequestArgs().size(); i++) {
                        String newName = replaceUrlDate.getRequestArgs().get(i).getName();
                        String newName1 = StringUtils.stringMatch(old1, newName);
                        if (!StringUtils.isEs(newName1)) {
                            str = str.replace(old1, newName1);
                            break;
                        }
                    }
                }


//                for (int v = 0; v < replaceUrlDate.getRequestArgs().size(); v++) {
//                    if (!replaceUrlDate.getRequestArgs().get(v).isReplace()) {
//
//                        if (count == 1) {
//
////                            System.out.println("包含 1个 >>>>>入参 字段名 数据 》》》》》" + replaceUrlDate.getRequestArgs().get(v).getName() + "......." + str);
//
//
//                            str = StringUtils.cutOutReplace("@Query(\"", "\")", str, replaceUrlDate.getRequestArgs().get(v).getName());
//                            break;
//                        } else if (count == 2 && replaceUrlDate.getRequestArgs().size() >= 2) {
//                            list.get(index).getRequestArgs().get(v).setReplace(true);
//                            String s1 = str.substring(str.indexOf("@Query(\"") + "@Query(\"".length(), str.indexOf("\")"));
//                            str = str.replace(s1, replaceUrlDate.getRequestArgs().get(v).getName());
//
//                            list.get(index).getRequestArgs().get(v).setReplace(true);
////                            System.out.println("包含 2个 >>>>>> 入参 字段名 数据 》》》" + replaceUrlDate.getRequestArgs().get(v).getName() + "》》" + replaceUrlDate.getRequestArgs().get(v + 1).getName() + "......." + str);
//                            str = StringUtils.cutOutReplace("@Query(\"", "\")", str, replaceUrlDate.getRequestArgs().get(v + 1).getName());
//                            break;
//                        }
//                    }
//                }
            } else {
//                System.out.println(str + "---------" + replaceUrlDate.getRequestArgs());
            }
            if (str.contains(");")) {
                replaceUrlDate = null;
                index = -1;
            }
        }

        return str;
    }

    /**
     * 根据 读取到的 字符串 匹配 要替换的
     * <p>
     * 在 方法名 集合中 查找
     *
     * @param line
     * @return
     */
    private Map.Entry<String, String> getString1(String line) {
        if (StringUtils.isEs(line)) {
            return null;
        }
        for (Map.Entry<String, String> en : MethodNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.trim().equals(en.getValue().trim())) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en;
            }
        }
        return null;
    }

    /**
     * 在数据类中 查找
     *
     * @param line
     * @return
     */
    private Map.Entry<String, String> getString2(String line) {
        if (StringUtils.isEs(line)) {
            return null;
        }
        for (Map.Entry<String, String> en : beanNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.trim().equals(en.getKey().trim())) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en;
            }
        }
        return null;
    }

    /**
     * 在数据类中 查找
     *
     * @param line
     * @return
     */
    private Map.Entry<String, String> getString3(String line) {
        if (StringUtils.isEs(line)) {
            return null;
        }
        for (Map.Entry<String, String> en : beanNameList.entrySet()) {
//            System.out.println("replaceMap 中 对应的" + line + " 数据 -----" + en + "----" + en.getKey());
            if (line.trim().equals(en.getValue().trim())) {
//                System.out.println("replaceMap 中 成功的数据 -----" + en);
                return en;
            }
        }
        return null;
    }

    /**
     * 获取 多个字母
     *
     * @param size
     * @return
     */
    public String getMultiLetter(int size) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < size; i++) {
            sb.append((char) (int) (Math.random() * 26 + 97));
        }

        return sb.toString();
    }

    /**
     * 起始 点
     */
    public void replaceUrl() {
        /**
         * 接口 数据
         */
        list = new GetEmployDate().getDate(uRLDir);
        replaceSrcDir(apiDir);

        ArrayList<String> listFileName = new ArrayList<>();

        //替换 调用网络接口的方法
        if (null != MethodNameList && MethodNameList.size() > 0) {
            new NetMethodReplace().replaceCode(MethodNameList, listFileName);
        }

        if (null != mBeadNameList && mBeadNameList.size() > 0) {
            new BeanCarryOut().replaceBean(mBeadNameList,beanNameList);
        }
//        //替换 调用网络接口返回 数据类名
//        if (null != beanNameList && beanNameList.size() > 0) {
//            try {
//                Class clazz;
//                try (GroovyClassLoader loader = new GroovyClassLoader()) {
//                    clazz = loader.loadClass("com.github.better.replaceUrl.replace.BeanNameReplace");
//                }
//                // 获得GroovyShell_2的实例
//                GroovyObject groovyObject = (GroovyObject) clazz.newInstance();
//                // 反射调用sayHello方法得到返回值
//                groovyObject.invokeMethod("replaceCode", new Object[]{mBeadNameList, beanNameList, listFileName});
//
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
    }

    /**
     * 添加 数据类 与  出参 参数 的对应 关系
     */
    private void AddDataRelationship(String s, List<RequestArgsData> requestArgsDataList) {
        if (mBeadNameList.containsKey(s)) {
            requestArgsDataList.addAll(mBeadNameList.get(s));
        }
        mBeadNameList.put(s, requestArgsDataList);
    }
}


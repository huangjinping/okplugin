package com.example.gethttp;


import com.example.beans.AskFororListData;
import com.example.beans.AskFororQianData;
import com.example.beans.BancokLisdstData;
import com.example.beans.BancokMingListData;
import com.example.beans.BaseRespData;
import com.example.beans.CommAddBankData;
import com.example.beans.ConfirmUseLoanData;
import com.example.beans.DictionaryConfigData;
import com.example.beans.GetLoadingBean;
import com.example.beans.IneBacokSjowData;
import com.example.beans.IneData;
import com.example.beans.InviteData;
import com.example.beans.IsFirstSendCodeEntry;
import com.example.beans.IsiUserData;
import com.example.beans.JianQuanListData;
import com.example.beans.LivefaceTokenData;
import com.example.beans.OurSoftBanBenData;
import com.example.beans.OusrReconnData;
import com.example.beans.PageStartKaiData;
import com.example.beans.PayByExceedingBean;
import com.example.beans.PayByExceedingOrderBean;
import com.example.beans.RechargeRepayBean;
import com.example.beans.RepayTypeBean;
import com.example.beans.RepaymentDetailsBean;
import com.example.beans.ShortUrlBean;
import com.example.beans.TiContractData;
import com.example.beans.UserBackData;
import com.example.beans.ValidImgPicCodeData;
import com.example.beans.ViewPaperHomeData;
import com.example.beans.WindConrtralUnOkCheckIfData;
import com.example.beans.YourPersonValueData;

import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface ApiNetUrl {



    /**
     * 版本更新
     */
    @POST("yoi/yok-sep-base/renewal/bitCheck")
    Observable<BaseRespData<OurSoftBanBenData>> ApiUrlChecoVercasion();

    /**
     * 启动图
     */
    @POST("yoi/yok-sep-base/prbcs/getPrbcs")
    Observable<BaseRespData<PageStartKaiData>> ApiUrlStaraoImagore();

    /**
     * 请求图形验证码
     *
     * @param cellNum 手机号
     * @return code为0时，获取成功并返回图形验证码数据（base64编码字符串），否则获取失败，返回错误信息
     */
    @POST("yoi/yok-sep-base/picYokVv/picYokVv")
    Observable<BaseRespData<ValidImgPicCodeData>> ApiUrlCaphchaOTPGet(@Query("yokPe") String cellNum);

    /**
     * 字典配置项
     *
     * @param searchKind dictType需要base64加密
     * @return dictValue
     */
    @POST("yoi/yok-sep-base/yokDict")
    Observable<BaseRespData<DictionaryConfigData>> ApiUrlDictoionaraySetitng(@Query("yokType") String searchKind);

    /**
     * 获取短信验证码
     *
     * @param cellNum      手机号
     * @param checkType    REGISTER/FINDPASS
     * @param validImgCode 图验
     * @return code为0时，获取成功并返回图形验证码数据（base64编码字符串），否则获取失败，返回错误信息
     */
    @POST("yoi/yok-sep-base/sendYok/yokSms")
    Observable<BaseRespData<ValidImgPicCodeData>> ApiUrlCodigoVerifGet(@Query("yokPe") String cellNum,
                                                                       @Query("yokType") String checkType,
                                                                       @Query("imgYok") String validImgCode);

    /**
     * 获取语音验证码
     *
     * @param cellNum      手机号
     * @param checkType    REGISTER/FINDPASS
     * @param validImgCode 图验
     * @return code为0时，获取成功并返回图形验证码数据（base64编码字符串），否则获取失败，返回错误信息
     */
    @POST("yoi/yok-sep-base/sendYok/yokVoice")
    Observable<BaseRespData<ValidImgPicCodeData>> ApiUrlVozOtpGet(@Query("yokPe") String cellNum,
                                                                  @Query("yokType") String checkType,
                                                                  @Query("imgYok") String validImgCode);

    /**
     * 银行详细获取接口（编码及名称）
     *
     * @return bean
     */
    @POST("yoi/yok-sep-base//bankIn/duiSec")
    Observable<BaseRespData<List<BancokMingListData>>> ApiUrlBancoInfoList();

    /**
     * 5：位置，6：终端信息
     *
     * @return
     */
    @POST("yoi/yok-sep-base/put/cuteftpJson")
    Observable<BaseRespData<String>> ApiUrlUpDaraByJsonDaro(@Query("yokTy") String uploadType, @Query("yd") String yd);


    /**
     * 已文件流的形式上传文件
     *
     * @param maps 请求参数
     * @param body type  上传类型 1.APP列表；2.通讯录；4.短信；7.通话记录；10:相册；
     *             data  File文件流
     *             dataMark  若抓取数据为空，则设置为"NO_DATA"
     * @return
     */
    @Multipart
    @POST("yoi/yok-sep-base/put/cuteftpFile")
    Call<BaseRespData<String>> ApiUrlUpDaraByFileoDara(@QueryMap Map<String, Object> maps,
                                                       @Part("flow\"; filename=\"data.txt\"") RequestBody body);

    /**
     * 联系人信息提交
     *
     * @param firstUrgentContact   第一紧急联系人关系code  1 配偶  2 父亲 3 母亲  4 子女 5 兄弟 6 姐妹
     * @param firstRelativesName   第一紧急联系人名称
     * @param firstRelativesPhone  第一紧急联系人手机号
     * @param secondRelativesName  第二紧急联系人姓名
     * @param secondRelativesPhone 第二紧急联系人手机号
     */
    @POST("yoi/yok-sep-biz/infoRe/tjContact")
    Observable<BaseRespData<TiContractData>> ApiUrlRelacionSave(@Query("firstRelation") String firstUrgentContact,
                                                                @Query("firstCall") String firstRelativesName,
                                                                @Query("firstMobile") String firstRelativesPhone,
                                                                @Query("secondRelation") String secondRelativesName,
                                                                @Query("secondCall") String secondRelativesPhone);

    /**
     * 用户信息回显
     * 1.基本信息 2.工作信息 3.联系人信息4.银行卡信息
     */
    @POST("yoi/yok-sep-biz/infoRe/xs")
    Observable<BaseRespData<UserBackData>> ApiUrlInputInfoearBaccoShoarw(@Query("form") String type);

    /**
     * nano上传身份证正面信息(识别)
     *
     * @param part 身份证正面照
     * @param map  参数
     * @return 0为成功
     */
    @Multipart
    @POST("yoi/yok-sep-biz/shibie/tjOcr")
    Observable<BaseRespData<IneData>> ApiUrlUPINEFrontalByNano(@Part MultipartBody.Part part,
                                                               @QueryMap Map<String, Object> map);

    /**
     *上传身份证正面信息(识别)
     *
     * @param part 身份证正面照
     * @param map  参数
     * @return 0为成功
     */
    @Multipart
    @POST("yoi/yok-sep-biz/shibie/tjOcr")
    Observable<BaseRespData<IneData>> ApiUrlUPINEFrontalByPanda(@Part MultipartBody.Part part,
                                                                @QueryMap Map<String, Object> map);


    /**
     * 活体前获取token
     */
    @POST("yoi/yok-sep-biz/shibie/initFaceToken")
    Observable<BaseRespData<LivefaceTokenData>> ApiUrlTokenGet(@Query("fws") String fws);



    /**
     * 人脸对比的信息
     *
     * @return 0为成功
     */
    @Multipart
    @POST("yoi/yok-sep-biz/shibie/faceDb")
    Observable<BaseRespData<IneData>> ApiUrlFaceContrast(@Part MultipartBody.Part part,
                                                         @QueryMap Map<String, Object> map);

    /**
     * 身份识别组合信息保存
     *
     * @param firstName  第一姓
     * @param secondName 第二姓
     * @param fullName   全名
     * @return
     */
    @POST("yoi/yok-sep-biz/shibie/tjCompose")
    Observable<BaseRespData> ApiUrlINEAllInfoSave(@Query("firstCall") String firstName,
                                                  @Query("secondCall") String secondName,
                                                  @Query("fullCall") String fullName);

    /**
     * 获取ocr数据回显
     */
    @POST("yoi/yok-sep-biz/shibie/xsCurp")
    Observable<BaseRespData<IneBacokSjowData>> ApiUrlINECardraBacckShow();

    /**
     * 提交验证银行卡，添加银行卡信息,信息收集
     *
     * @return bean
     */
    @POST("yoi/yok-sep-biz/yhyz/tjYh")
    Observable<BaseRespData<CommAddBankData>> ApiUrlAddorBancoInfor(@Query("yhId") String bankType, //1.CLABE 2.借记卡
                                                                    @Query("yhType") String bankCardNum,//银行卡号
                                                                    @Query("yhNo") String bankNameId,//银行名称code
                                                                    @Query("yhCode") String comeMark,//1.验证 0.不验证
                                                                    @Query("isYz") String bankId);//银行卡id

    /**
     * 获取借款试算信息
     *
     * @return
     */
    @POST("yoi/yok-sep-biz/jyYo/jyPreInfo")
    Observable<BaseRespData<ConfirmUseLoanData>> ApiUrlPrestamoCountInfor();

    /**
     * 确认借款
     *
     * @param amt
     * @param bankId 选中银行卡ID
     * @return
     */
    @POST("yoi/yok-sep-biz/jyYo/confirmJy")
    Observable<BaseRespData<AskFororQianData>> ApiUrlPrestamoConfirme(@Query("cash") String amt,
                                                                      @Query("yhId") String bankId,
                                                                      @Query("yhjId") String yhjId);

    /**
     * 首页多场景
     */
    @POST("yoi/yok-sep-biz/sceneYok/aboutYo")
    Observable<BaseRespData<ViewPaperHomeData>> ApiUrlDuoChangJing();

    /**
     * 调用风控规则
     */
    @POST("yoi/yok-sep-biz/riskYo/callRisk")
    Observable<BaseRespData<WindConrtralUnOkCheckIfData>> ApiUrlWindControlRule();

    /**
     * 获取风控规则调用结果，不需要应用ID
     */
    @POST("yoi/yok-sep-biz/riskYo/riskResult")
    Observable<BaseRespData<GetLoadingBean>> ApiUrlWindControlRuleResult();

    /**
     * 获取个人中心银行卡项是否展示
     */
    @POST("yoi/yok-sep-user/yhInfo/isXs")
    Observable<BaseRespData<String>> ApiUrlIsShowBancoListInSiMi();

    /**
     * 获取银行卡列表
     * todo 出参
     *
     * @return
     */
    @POST("yoi/yok-sep-user/yhInfo/yhSet")
    Observable<BaseRespData<List<BancokLisdstData>>> ApiUrlBancoList();

    /**
     * 保存选中默认银行卡
     *
     * @param bankId 银行卡号
     * @return
     */
    @POST("yoi/yok-sep-user/yhInfo/save")
    Observable<BaseRespData<String>> ApiUrlSetSelecorBancoToDefalua(@Query("yhId") String bankId);


    /**
     * 验证用户是否注册 0-已注册 1未注册
     *
     * @param cellNum 手机号
     * @return result
     */
    @POST("yoi/yok-sep-user/userYo/reWiYok")
    Observable<BaseRespData<String>> ApiUrlUserRegistrerIs(@Query("yokPe") String cellNum);

    /**
     * 用户注册登录
     *
     * @param phone       手机号
     * @param msgCode     验证码
     * @param sourceFlag  注册来源：appStore、wap、android
     * @param phoneType   手机操作系统类型：【P1001 ios】【P1002 安卓】
     * @param channelCode 渠道编号【渠道分享用】
     * @param voiceCode   语音验证码
     * @param password    密码
     * @return result
     */
    @POST("yoi/yok-sep-user/userYo/reYok")
    Observable<BaseRespData<IsiUserData>> ApiUrlRegistaraAndEnviar(@Query("yokPe") String phone,
                                                                   @Query("smsYok") String msgCode,
                                                                   @Query("sof") String sourceFlag,
                                                                   @Query("yokType") String phoneType,
                                                                   @Query("yokChannel") String channelCode,
                                                                   @Query("voiceYok") String voiceCode,
                                                                   @Query("cip") String password);

    /**
     * 退出登录
     *
     * @return
     */
    @POST("yoi/yok-sep-user/userYo/exLoYok")
    Observable<BaseRespData> ApiUrlVolverOUT();

    /**
     * 获取信用报告
     */
    @POST("yoi/yok-sep-user/userYo/retYok")
    Observable<BaseRespData<YourPersonValueData>> ApiUrlRemumen();

    /**
     * 订单列表
     *
     * @return
     */
    @POST("yoi/yok-sep-user/jyInfo/jySet")
    Observable<BaseRespData<AskFororListData>> ApiUrlHistoreisOrdroer();

    /**
     * 用户重置密码
     *
     * @param cellNum     手机号
     * @param msgCode     验证码
     * @param voiceCode   语音验证码
     * @param newPassword 新密码
     * @return result
     */
    @POST("yoi/yok-sep-user/userYo/changeCip")
    Observable<BaseRespData<IsiUserData>> ApiUrlRetrePwd(@Query("yokPe") String cellNum,
                                                         @Query("smsYok") String msgCode,
                                                         @Query("voiceYok") String voiceCode,
                                                         @Query("newCip") String newPassword);

    /**
     * 用户登录
     *
     * @param phone     手机号
     * @param phoneType 手机操作系统类型：【P1001 ios】【P1002 安卓】
     * @param password  密码
     * @return result
     */
    @POST("yoi/yok-sep-user/userYo/loYok")
    Observable<BaseRespData<IsiUserData>> ApiUrlUserLaiBa(@Query("yokPe") String phone,
                                                          @Query("yokType") String phoneType,
                                                          @Query("cip") String password);

    /**
     * 优惠券列表
     *
     * @param page
     * @param useType 类型 1：有效 3：失效或过期
     * @return CouponListBean
     */
    @POST("yoi/yok-sep-user/yhjDeal/yhjSet")
    Observable<BaseRespData<List<JianQuanListData>>> ApiUrlCoupoornList(@Query("form") String form,
                                                                        @Query("useMold") String useType);

    /**
     * 使用优惠券
     *
     * @param couponId 优惠券ID
     */
    @POST("yoi/yok-sep-user/yhjDeal/useYhj")
    Observable<BaseRespData<String>> ApiUrlUsearCoupoorn(@Query("yhjId") String yhjId);

    /**
     * 获取邀请活动开关
     */
    @POST("yoi/yok-sep-user/yqDeal/kaiguan")
    Observable<BaseRespData<InviteData>> ApiUrlInviteActiveSet(@Query("form") String form);

    /**
     * 精品列表
     *
     * @param page 页码
     *
     * source 1精品列表,2精品成功列表,3精品拒绝列表
     * @return
     */
    @POST("yoi/yok-sep-assist/jpRe/jpSet")
    Observable<BaseRespData<List<OusrReconnData>>> ApiUrlRecromLisrt(@Query("jpPg") String jpPg,
                                                                     @Query("form") String form);

    /**
     * 精品点击统计
     *
     * @param productId   应用ID
     * @param clickSource 0' 精品列表；'1' 拒贷页
     * @param eventType   0-点击精品按钮 ; 1-点击产品apply
     * @return
     */
    @POST("yoi/yok-sep-assist/jpPoint/save")
    Observable<BaseRespData<String>> ApiUrlRecormEvenortCount(@Query("jpId") String productId,
                                                              @Query("form") String clickSource,
                                                              @Query("origin") String eventType);
    /**
     * 获取还款方式
     *
     * @param applyId 订单号
     */
    @POST("yoi/yok-sep-repayment/repayYo/acCharge")
    Observable<BaseRespData<List <RepayTypeBean>>> onrepayMethod(@Query("jyId") String jyId,@Query("chargeForm") String chargeForm);

    /**
     * 订单详情接口
     *
     * @param orderId 订单号
     */
    @POST("yoi/yok-sep-repayment/repayYo/jyDetail")
    Observable<BaseRespData<RepaymentDetailsBean>> ApiUrlPagoInfora(@Query("jyId") String jyId);

    /**
     * 申请充值还款
     *
     * @param applyId      订单编号
     * @param amount       充值金额
     * @param repayChannel 订单编号panda
     * @param paymentType  主动充值:0,展期充值:1
     *    @param zfAmt  通道费
     */
    @POST("yoi/yok-sep-repayment/repayYo/charge")
    Observable<BaseRespData<RechargeRepayBean>> ApiUrlChongZhiPagoShenQing(@Query("jyId") String applyId,
                                                                           @Query("cash") String amount,
                                                                           @Query("chargeChannel") String repayChannel,
                                                                           @Query("chargeForm") String paymentType,
                                                                           @Query("chargeMeans") String payMeans,
                                                                           @Query("rollCash") String rollCash);





    /**
     * 获取展期试算
     *
     * @param lonId 订单编号
     */
    @POST("yoi/yok-sep-repayment/roll/acDetail")
    Observable<BaseRespData<PayByExceedingBean>> onAskExceedingTrialCalculation(@Query("jyId") String lonId);

    /**
     * 申请展期订单
     *
     * @param lonId 订单编号
     */
    @POST("yoi/yok-sep-repayment/roll/apply")
    Observable<BaseRespData<PayByExceedingOrderBean>> onAskExceedingOrder(@Query("jyId") String lonId);




    /**
     * 活动点击来源统计
     *
     * @param eventId AE03:首页广告、AE04:个人中心广告
     * @return
     */
    @POST("yoi/yok-sep-assist/invitePoint/save")
    Observable<BaseRespData<String>> clicksaveRecordApply(@Query("form") String form);




    /**
     * 获取短链接信息
     */
    @POST("yoi/yok-sep-base/shortUrl/getShortUrl")
    Observable<BaseRespData<ShortUrlBean>> getchangeshorturl();


    /**
     * 判断是否当天首次触发短信验证码
     *
     * @param mobile      手机号
     */
    @POST("yoi/yok-sep-base/shortUrl/getShortUrl")
    Observable<BaseRespData<IsFirstSendCodeEntry>> onAskSmsCodeGetUrlInter(@Query("handsetPin") String mobile);




}

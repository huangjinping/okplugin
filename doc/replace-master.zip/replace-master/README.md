
# AndroidResourceTools

更改 资源 代码

# 使用说明

#### 1. 在项目的根目录`build.gradle`,添加依赖如下

```
    repositories {
        maven { url 'https://www.jitpack.io' }

    }
    dependencies {
        classpath 'com.gitee.19890909:replace:0.3.6'
    }
    
    在对应的 module 下 build.gradle中 添加 
    apply from: "../replace_config.gradle"
     
    
    
```
下载(replace_config.gradle)配置文件   [配置文件](https://gitee.com/19890909/replace/blob/master/replace_config.gradle)
#### 使用 

   [url 替换](https://gitee.com/19890909/replace/blob/master/SRC.md)

   [资源 替换](https://gitee.com/19890909/replace/blob/master/RES.md)

   [布局id 替换](https://gitee.com/19890909/replace/blob/master/REPLACE_ID.md)


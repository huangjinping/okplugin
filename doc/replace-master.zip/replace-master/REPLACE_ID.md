
# AndroidResourceTools

1.修改 android 布局 id

2.修改 id 依赖

3.修改 控件 名


# 使用说明

#### 1. 在对应的 module 下 `build.gradle`下，apply 插件，如下：

```groovy
apply plugin: 'com.android.application'
apply plugin: 'ReplaceTools'  // 资源重命名插件

// 配置插件dsl
replaceIdConfig {
   /**
    * id 命名规范
    *
    * 随机数字  4(位数)_RANDOMNUMBER
    *
    * 随机字母  4(位数)_RANDOMLETTERS
    *
    * 无 位数 默认1
    * 分割 用  _
    *
    * 其余 数字 字母  直接使用
    *
    * 例如：car_RANDOMNUMBER_6RANDOMLETTERS_4RANDOMLETTERS
    */
   namingScheme = 'car_RANDOMNUMBER_6RANDOMLETTERS_4RANDOMLETTERS'
}
```

#### 3. 运行

clean 工程后，
可以发现，在对应的 module 下，可发现 `resourcetools` task 组，
展开：

1.点击「replaceId」 （替换 布局id）执行

#### 4.问题


问题  | 状态| 备注
---|---|---
id 与其他变量 一样时 更改错误   | 未更改 | 影响使用
代码中声明 变量与 id 不同时， 变量更改不可控，与id名不一致  | 未更改 | 不影响使用



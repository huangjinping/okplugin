
# AndroidResourceTools

修改 （小幺鸡）接口url

# 使用说明


#### 1. 在对应的 module 下 `build.gradle`下，apply 插件，如下：

```groovy
apply plugin: 'com.android.application'
apply plugin: 'ReplaceTools'  // 资源重命名插件

// 配置插件dsl
urlConfig {
    urlTextPath = 'nraMYuSPO.mjson' //接口文档 名称
    apiClass ='com.example.gethttp.ApiNetUrl'  //接口类 全名

   //不设置 前缀 后缀  使用默认
//    /**
//     * api url 方法
//     * 设置时 增加 （前缀 后缀）
//     */
//    apiUrlMethodName = "get_";
//    /**
//     * view  调取 接口的 方法
//     * 设置时 增加 （前缀 后缀）
//     */
//    urlPgetMethodName = "get_";
//    /**
//     * url Result方法
//     * 设置时 增加 （前缀 后缀）
//     */
//    urlResultMethodName = "_ReSult";
//
//    /**
//     * url Error Result方法
//     * 设置时 增加 （前缀 后缀）
//     */
//    urlErrorResultMethodName = "_Error";

//    /**
//     * mvp 中调取 接口的 变量
//     */
//    viewMethodName = "mView";
}
```

#### 3. 运行 

###### 1. 从小幺鸡 导出 .mjson 文件 拷贝到 总项目 下      
###### 2.在 urlConfig 中 配置 “接口 文档 名称”
###### 3.clean 工程后，
   可以发现，在对应的 module 下，可发现 `resourcetools` task 组，
   展开：
   
   1.点击「replaceResName」 （替换 资源名）执行；<br/>2.点击 [replaceUrl] （替换接口）
   

# 特别说明(特别重要)

>1. 因是直接替换文件，千万不要在主分支，主开发分支使用，建议使用新分支，测试ok后，合并；
>2. 目前插件没有加入文件事务处理，即：不能实现要么全部成功，要么全部失败；


## `现有功能支持`：

 *|功能|问题 
---|---|---
1 | 替换 接口 url| 注释不能对应  会发生 url没有更改的问题
2 | 替换 入参 字段名|入参 字段 顺序 不能 跟 原来一致的问题



# TODO
1. 出参 替换 待支持 
2. 出参 get set 方法  引用 修改  待支持
3. url接口 方法名  更改  待支持
4. view 接口方法名 更改  待支持
5. Presenter 接口 方法名 更改 待支持

# 问题 
问题  | 状态| 备注
---|---|---
